//���汾�����еĹ�����������ˮλ�ƺ�����ʪ�ȴ��������ն˽ڵ�����Ӧ���ڵ�����ʱ���߻��� 2013.7.15
//�������˲�ͬˮλ���������͵Ļ�ȡ���Σ�2013.7.17��
//��������ˮλ����ʱ�ϵ�����Σ�2013.7.17��
//��ˮλ��Ĭ�����͸�Ϊ3���ӽ�ʵ��Ӧ�ã�����������Ϊ����������Ϊ���ñ��Ĳ�����2013.7.23��
//�������յ�����ackӰ�����ݲɼ�ʱ���bug(2013.7.24)
//p1_1��Ϊˮλ�Ƶĵ�Դ���ƿ��أ�2013.7.28��
//�޸�NWK_INDIRECT_MSG_TIMEOUT��POLL_RATE��2013.7.28�� ��δ�ҵ�һ�ֺ��ʵķ���
//����zigbee�ڵ�����������ñ��ĺ�ˮλ�ƹر����ޣ�2013.7.31�� 
//���� ��Ŀ���չر�ˮλ�ƣ�ƽʱ���ر�ˮλ�ƣ�2013.8.13��
//�ȶ����ԣ�100h�����Ѳ�����/*��ʱ����ܲ��ȶ���һ��ʱ�����ͨ�ڵ�ȴ����¹���*/���⣨2013.8.25��
/**************************************************************************************************
  Filename:       p2p_test.c
  Revised:        $Date: 2007-10-27 17:16:54 -0700 (Sat, 27 Oct 2007) $
  Revision:       $Revision: 15793 $

  Description:    Generic Application (no Profile).


  Copyright 2004-2007 Texas Instruments Incorporated. All rights reserved.

  IMPORTANT: Your use of this Software is limited to those specific rights
  granted under the terms of a software license agreement between the user
  who downloaded the software, his/her employer (which must be your employer)
  and Texas Instruments Incorporated (the "License").  You may not use this
  Software unless you agree to abide by the terms of the License. The License
  limits your use, and you acknowledge, that the Software may not be modified,
  copied or distributed unless embedded on a Texas Instruments microcontroller
  or used solely and exclusively in conjunction with a Texas Instruments radio
  frequency transceiver, which is integrated into your product.  Other than for
  the foregoing purpose, you may not use, reproduce, copy, prepare derivative
  works of, modify, distribute, perform, display or sell this Software and/or
  its documentation for any purpose.

  YOU FURTHER ACKNOWLEDGE AND AGREE THAT THE SOFTWARE AND DOCUMENTATION ARE
  PROVIDED �AS IS?WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
  INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, TITLE,
  NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL
  TEXAS INSTRUMENTS OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER CONTRACT,
  NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER
  LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
  INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE
  OR CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT
  OF SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
  (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.

  Should you have any questions regarding your right to use this Software,
  contact Texas Instruments Incorporated at www.TI.com.
**************************************************************************************************/

/*********************************************************************
  This application isn't intended to do anything useful, it is
  intended to be a simple example of an application's structure.

  This application sends "Hello World" to another "Generic"
  application every 15 seconds.  The application will also
  receive "Hello World" packets.

  The "Hello World" messages are sent/received as MSG type message.

  This applications doesn't have a profile, so it handles everything
  directly - itself.

  Key control:
    SW1:
    SW2:  initiates end device binding
    SW3:
    SW4:  initiates a match description request
*********************************************************************/

/*********************************************************************
 * INCLUDES
 */

#include "OSAL.h"
#include "AF.h"
#include "ZDApp.h"
#include "ZDObject.h"
#include "ZDProfile.h"

#include "p2p_test.h"
#include "DebugTrace.h"

#include "SPIMgr.h"
#include <string.h>

#if !defined( WIN32 )
  #include "OnBoard.h"
#endif

/* HAL */
#include "hal_lcd.h"
#include "hal_led.h"
#include "hal_key.h"
#include "hal_uart.h"
//#include "Hal_Sensor.h"  
#include "Hal_defs.h"
#include "hal_adc.h"
/*********************************************************************
 * MACROS
 */
//zyq add
#define ADDFLAG16(a,Byte) ((uint16)(a|(0x0001<<(Byte-1))))
#define TYPE_SENSOR 0x00
#define TYPE_COMMAND 0x08
#define TYPE_MAINTAIN 0x01
#define TYPE_ACK 0x0f
//#define TYPE_ZIGBEE_RESTART_COMMAND  0x04

#define TYPE_REPORT 0x02
#define TYPE_QUARY 0x09
#define TYPE_ACK_UP 0x00

//RelationMsg up or down link typecode
#define RELATION_MSG_UP 0x01
#define RELATION_MSG_DOWN 0x01
//#define TYPE_CODE_SENSOR_ILLUMINATION 0X01
//#define TYPE_CODE_SENSOR_TEMPERATURE 0X02
#define TYPE_CODE_SENSOR_RAIN 0x01
#define TYPE_CODE_SENSOR_SOIL_HUMIDITY 0X02
#define TYPE_CODE_SENSOR_WATER_GAGE 0x03
#define TYPE_CODE_SENSOR_ACCELEROMETER 0x04
#define TYPE_CODE_SENSOR_PORE_PRESSURE 0x05
#define TYPE_CODE_SENSOR_READ_VCC 0X07

//define sensor's ID
#define RAIN_ID 0x01
#define SOIL_ID 0x02
#define WATER_GAGE_ID 0x03
#define EARTHQUAKE_ID 0x04
#define PORE_ID 0x05

//define that zigbee have the sensor or not
#define RAIN_FLAG 0x00
#define SOIL_FLAG 0x00
#define WATER_GAGE_FLAG 0x01
#define EARTHQUAKE_FLAG 0x00
#define PORE_FLAG 0x00
#define MAX_ID 8

#define COMMAND_TYPE_RAIN 1    //����Kֵ
#define COMMAND_TYPE_SOIL_HUMIDITY 2  //����ʪ��Kֵ
#define COMMAND_TYPE_WATER_GAGE 3   //ˮλKֵ
#define COMMAND_TYPE_VIBRATIO 4   //��Kֵ
#define COMMAND_TYPE_PORE_PRESS 5  //��ѹKֵ
#define COMMAND_TYPE_RAIN_KVALUE 6   //����Nֵ
#define COMMAND_TYPE_WATER_HIGHTYPE 7  //ˮλ�ո�����
#define COMMAND_TYPE_HELLO 8//HelloƵ��
#define COMMAND_TYPE_WATER_T 9 //ˮλ������Ӧ�ɼ��������Ӽ��Tȡֵ
#define COMMAND_TYPE_WATER_EDGE_A 10 //ˮλ������Ӧ�߽�ȡֵA
#define COMMAND_TYPE_WATER_EDGE_B 11 //ˮλ������Ӧ�߽�ȡֵB
#define COMMAND_TYPE_WATER_EDGE_C 12 //ˮλ������Ӧ�߽�ȡֵC
#define COMMAND_TYPE_ZIGBEE_RESTART 13 //zigbee����������
#define COMMAND_TYPE_ACCEPTANCE 14     //��Ŀ����

//ȫ��δ�õ�
#define TYPE_CODE_COMMAND_MODIFY_K 0x00
#define TYPE_CODE_COMMAND_MODIFY_N 0x01
#define TYPE_CODE_COMMAND_REQUIRE 0x02
#define TYPE_CODE_COMMAND_SENSOR_STOP_EVT 0x03
#define TYPE_CODE_MAINTAIN_RELATION 0x01
#define TYPE_CODE_MAINTAIN_RESET_TIME 0x06

//define wate gage information type
#define Station_Num 0x01
#define Water_Func_Code 0x03
#define First_Addr0 0x0000
#define First_Addr1 0x0001
#define First_Addr2 0x0002
#define First_Addr3 0x0003
#define Water_num 0x0002
#define Default_Water_Gage First_Addr3

//define soil type for select formula(δʹ��)  
#define  Clay_Soil  0x00
#define  Loam_Soil  0x01
#define  Sand_Soil  0x02

#define MAIN_VERSION 0x00
#define SUB_VERSION 0x01

#define FREQ 0x00
#define REQUIRE 0x01

#define ACK_YES 0x01
#define ACK_NO 0x00


#define DEBUG 1

//static uint16 SerialNumber;
static uint8 RES;
static uint8 ARM_ID;
static uint8 Zigbee_ID;
typedef struct
{
  uint8 type : 4;
  uint8 SubVersion : 1;
  uint8 MainVersion : 2;
  uint8 AckRequire : 1;
  uint8 TypeCode;
  uint8 sn[2];    //serial number
} AppHead_t;

typedef struct
{
  uint8 ARM_id :4;
  uint8 r : 4;
  uint8 sensor_type:4;
  uint8 Zigbee_id :4;
} NodeId_t;

typedef struct
{
  uint8 time[4]; 
  NodeId_t NodeId;  
} NodeIdAndTime_t;

typedef struct
{
  AppHead_t AppHead;
  NodeIdAndTime_t NodeIdAndTime;
  uint8 count[2];
} RainMsg_t;

typedef struct
{
  AppHead_t AppHead;
  NodeIdAndTime_t NodeIdAndTime;
  uint8 AdcVcc[2];
  uint8 AdcValue[2];
 // float SoilValue;
} Soil_Humidity_t;

typedef struct
{
  AppHead_t AppHead;
  NodeIdAndTime_t NodeIdAndTime;
  uint8 AdcVcc[2];
  uint8 AdcValue[2];
 // float Accelevalue;
} Accelerometer_t;

typedef struct
{
  AppHead_t AppHead;
  NodeIdAndTime_t NodeIdAndTime;
  uint8 AdcVcc[2];
} Vccvalue_t;

typedef struct
{
  AppHead_t AppHead;
  NodeIdAndTime_t NodeIdAndTime;
} ResetTimeMsg_t;

typedef struct
{
  AppHead_t AppHead;
  uint8 Num[2];
  NodeId_t NodeId[MAX_ID];
} RelationMsg_t;  

typedef struct
{
  AppHead_t AppHead;
  NodeId_t NodeId;
} AppHeadNodeId_t;

typedef struct
{
  uint8 head[2];
  uint8 len;
} UartHeadMsg_t;

//water gage information
typedef struct
{
  AppHead_t AppHead;
  NodeIdAndTime_t NodeIdAndTime;
  // uint8 water_gage_type[2];
  uint8 water_gage_value[2];  
}Water_Gage_t;

typedef struct
{
   uint8 station_number;
   uint8 func_code;
   uint8 first_addr[2];
   uint8 read_num[2];
   uint8 crc[2];
}Water_Send_Infor_t;

typedef struct
{
   uint8 station_number;
   uint8 func_code;
   uint8 read_byte_num;
   uint8 data[8];
   uint8 crc[8];
}Water_read_Infor_t;

 struct RelationMap_t 
{
  uint16 addr16;
  uint8 Zigbee_id;
  struct RelationMap_t *next;
} ;

typedef struct
{
   AppHead_t AppHead;
   NodeId_t Src_NodeId;
} AckUP_t;

//�Լ���д


//���������������
typedef struct
{ 
  uint16 data[3];
  uint32 time[3];
}Watergage_data_and_time;


typedef struct
{ 
  float data[3];
  uint32 time[3];
}Soilhumidity_data_and_time;


typedef struct
{
  AppHead_t AppHead;
  NodeId_t NodeId;
  uint8 command_type;
  uint16 water_gage_type;      //COMMAND_TYPE_WATER_HIGHTYPE
  uint16 water_gage_freq;      //COMMAND_TYPE_WATER_GAGE
  uint16 water_gage_T;         //COMMAND_TYPE_WATER_T
  uint8  water_gage_A;         //COMMAND_TYPE_WATER_EDGE_A
  uint8  water_gage_B;         //COMMAND_TYPE_WATER_EDGE_B  
  uint8  water_gage_C;         //COMMAND_TYPE_WATER_EDGE_C  
}Zigbee_Restart_Command_t;

//�ϴ�Ԥ��ֵ�ͱ�������ʵ��ֵ�Ĳ�ֵ
static uint16 Water_gage_err;
static float Soil_humidity_err;
//�������Լ������к�
static uint16 Water_gage_SerialNumber;
static uint16 Soil_humidity_SerialNumber;
//����Ӧ�������ڵĵ��������ר���е�T��
uint16 Water_gage_time ;   
uint16 Soil_humidity_time ; 
//��ʱ���Ϊ��̬��
static uint32 now;
//��������Ԥ��ֵ
static uint16 Water_gage_forValue;
static float Soil_humidity_forValue;
//����һ�������data_and_time����
Watergage_data_and_time  Water_Gage_data_and_time;
Soilhumidity_data_and_time  Soil_humidity_data_and_time;

static uint8 no_charge_flag; 
static uint8 water_gage_on;
uint16 CheckWaterGageChargeTimeFreq;

//����߽�ֵ(ˮλ����ʼ��ַΪ0002��ˮλֵ��cm)
static uint8 Water_gage_err_a  ;
static uint8 Water_gage_err_b  ;
static uint8 Water_gage_err_c  ;

#define Soil_humidity_err_a  0.1  //0.1V
#define Soil_humidity_err_b  0.5  //0.5V
#define Soil_humidity_err_c  1.0  //1.0V

#define Water_gage_data_span 30000

static uint8 relation_done ;

//��Ŀ����  �������ղ��ر�ˮλ�ƣ����ټ̵�����Ƭ��ģ�
static uint8 acceptance;
/*********************************************************************
 * CONSTANTS
 */
#define CLKSPD  ( CLKCON & 0x01 )
#define DATA P1_1
#define SCK P1_0

// This list should be filled with Application specific Cluster IDs.
/*********************************************************************
 * TYPEDEFS
 */

/*********************************************************************
 * GLOBAL VARIABLES
 */

// This list should be filled with Application specific Cluster IDs.
const cId_t p2p_test_ClusterList[p2p_test_MAX_CLUSTERS] =
{
  p2p_test_CLUSTERID,
  p2p_test_108ID,
  p2p_test_RelationMsg,
  //fire_extinguisher_clusterId
};

const SimpleDescriptionFormat_t p2p_test_SimpleDesc =
{
  p2p_test_ENDPOINT,              //  int Endpoint;
  p2p_test_PROFID,                //  uint16 AppProfId[2];
  p2p_test_DEVICEID,              //  uint16 AppDeviceId[2];
  p2p_test_DEVICE_VERSION,        //  int   AppDevVer:4;
  p2p_test_FLAGS,                 //  int   AppFlags:4;
  p2p_test_MAX_CLUSTERS,          //  byte  AppNumInClusters;
  (cId_t *)p2p_test_ClusterList,  //  byte *pAppInClusterList;
  p2p_test_MAX_CLUSTERS,          //  byte  AppNumInClusters;
  (cId_t *)p2p_test_ClusterList   //  byte *pAppInClusterList;
};

// This is the Endpoint/Interface description.  It is defined here, but
// filled-in in p2p_test_Init().  Another way to go would be to fill
// in the structure here and make it a "const" (in code space).  The
// way it's defined in this sample app it is define in RAM.
endPointDesc_t p2p_test_epDesc;

/*********************************************************************
 * EXTERNAL VARIABLES
 */

/*********************************************************************
 * EXTERNAL FUNCTIONS
 */

/*********************************************************************
 * LOCAL VARIABLES
 */
byte p2p_test_TaskID;   // Task ID for internal task/event processing
                          // This variable will be received when
                          // p2p_test_Init() is called.
devStates_t p2p_test_NwkState;


byte p2p_test_TransID;  // This is the unique message ID (counter)


byte p2p_test_TransID;  // This is the unique message ID (counter)

afAddrType_t p2p_test_DstAddr;
  //uint8 p2p_msg[6];//the collect message
 uint16 shortaddr;
 uint16 fatheraddr;
//zyq add
static uint8 SendRainCountFreq; //wait SendRainCountFreq send to PAN
static uint16 SendRainTimeFreq; //every SendRainTimeFreq minute send rain msg
static uint32 SendRainRemainTime;//unit second
static uint8 RainCountNum;

static uint16 SendSoilHumidityTimeFreq;
static uint32 SendSoilHumidityRemainTime;

static uint16 SendAccelerometerTimeFreq;
static uint32 SendAccelerometerRemainTime;

static uint16 SendVccValueTimeFreq;
static uint32 SendVccValueRemainTime;

static uint16 SendWaterGageTimeFreq;
static uint16 SendWaterGageRemainTime;

static uint16 WaterGageUnit;
static uint8 SOIL_TYPE ;

static uint8 SoilHumidityFlag ;
static uint8 RainFlag ;
static uint8 WaterGageFlag;
static struct RelationMap_t *Head_Map=NULL;
static struct RelationMap_t *Tail_Map=NULL;
static uint16 FlagMap;




/*********************************************************************
 * LOCAL FUNCTIONS
 */
void p2p_test_ProcessZDOMsgs( zdoIncomingMsg_t *inMsg );
//void p2p_test_HandleKeys( byte shift, byte keys );
void p2p_test_MessageMSGCB( afIncomingMSGPacket_t *pckt );
//void p2p_test_SendTheMessage( void );

//zyq add
void p2p_test_recv_108clusterId(uint8 *pkt, uint8 length);
void p2p_test_recv_RelationMsgclusterId(uint8 *pkt,uint8 length,uint16 srcaddr);

void p2p_test_RecvFromUart(uint8 *Msg);
void p2p_test_SendToUart(uint8 *Data, uint8 DataLength);

void fill_AppHead(AppHead_t *AppHead, uint8 AckRequire, uint8 MainVersion, uint8 SubVersion, uint8 type, uint8 TypeCode);
void fill_AppHead_sn(AppHead_t *AppHead, uint8 AckRequire, uint8 MainVersion, uint8 SubVersion, uint8 type, uint8 TypeCode,uint16 SerialNumber);
void fill_NodeId_time(NodeIdAndTime_t *NodeIdAndTime,uint8 ARM_Id,uint8 Zigbee_id,uint8 sensor_type);
void SendMsg(uint8 *msg, uint8 MsgSize, afAddrType_t Dst, uint8 options,uint16 cID);

void p2p_test_SendResetRelativeTime( void );//δ�õ�
void p2p_test_SendRelationPkt( void );

void p2p_test_interrupt_rain(uint16 count);

void p2p_test_SendRainTimeFreqAndRequire( uint8 FreqOrRequire );
void p2p_test_SendSoilHumidityTimeFreqAndRequire( uint8 FreqOrRequire );
void p2p_test_SendAccelerometerTimeFreqAndRequire(uint8 FreqOrRequire);
void p2p_test_Send_VCC_VALUE(uint8 FreqOrRequire);
void p2p_test_Send_Water_Gage(uint8 FreqOrRequire,uint16 watergagetype);

void crc_water_gage(Water_Send_Infor_t * temp);
//unsigned short Read_SHT_TEMP_digital_sensor(void);
//unsigned short Read_SHT_HUMI_digital_sensor(void);

void p2p_test_StartDataSensorTimer(void);
extern uint8 halWait(unsigned char wait);
void insert_RelationMap(struct RelationMap_t *map,uint16 addr,uint8 zigbee_id);
uint8 search_RelationMap(uint16 addr);

//void READ_TEST( afIncomingMSGPacket_t *MSGpkt );

//�Լ���д

//��������
uint16 Water_gage_forecastValue(Watergage_data_and_time);
float Soil_humidity_forecastValue(Soilhumidity_data_and_time);
void HalUARTWrite_uint16(uint16);
void start_Water_gage_timer(void);
void start_Soil_humidity_timer(void);
float Soil_humidity_DtoA(uint16,uint16);
void check_water_gage_charge(void);

//���ˮλ���Ƿ��е磬��ֹˮλ��żȻ�ϵ���Զ��ָ�
void check_water_gage_charge()
{
  if(no_charge_flag ==1)      //��ʾˮλ��û��
  {
    osal_start_timerEx(p2p_test_TaskID,
                          p2p_test_SEND_WATER_GAGE_MSG_EVT, 
                          (SendWaterGageTimeFreq -60 )* 1000);
    osal_start_timerEx(p2p_test_TaskID,
                          p2p_test_CHECK_WATER_GAGE_CHARGE_MSG_EVT, 
                          CheckWaterGageChargeTimeFreq * 1000);
  }
  else if (no_charge_flag==0)    //��ʾˮλ��������������
  {
    osal_start_timerEx(p2p_test_TaskID,
                          p2p_test_CHECK_WATER_GAGE_CHARGE_MSG_EVT, 
                          CheckWaterGageChargeTimeFreq * 1000);
  }

#if DEBUG  
    uint8 x =255;
    HalUARTWrite(0,&x, sizeof(x));
#endif
} 


//��ȷ˳�����16λ���ݵ�����
void HalUARTWrite_uint16(uint16 data)
{
  typedef struct{
    uint8 x[2];
  }x;
   x xdata;       
  xdata.x[0] = (data>>8)&0x00FF;
  xdata.x[1] = data & 0x00FF;
  HalUARTWrite(0,(uint8*)&xdata, sizeof(xdata));
}

//Ԥ��ˮλ����һ����ֵ
uint16 Water_gage_forecastValue(Watergage_data_and_time sdat)
  {
     double x1,x2,x3;
     double y1,y2,y3;
     double b,k;
     
     if( (sdat.time[2]>sdat.time[1])&&(sdat.time[1]>sdat.time[0]) )
     {
       y1=sdat.data[0];
       x1=sdat.time[0];
       y2=sdat.data[1];
       x2=sdat.time[1];
       y3=sdat.data[2];
       x3=sdat.time[2];

     
     }
     else if( (sdat.time[0]>sdat.time[2])&&(sdat.time[2]>sdat.time[1]) )
     {
       y1=sdat.data[1];
       x1=sdat.time[1];
       y2=sdat.data[2];
       x2=sdat.time[2];
       y3=sdat.data[0];
       x3=sdat.time[0];
     }
     else
     {
       y1=sdat.data[2];
       x1=sdat.time[2];
       y2=sdat.data[0];
       x2=sdat.time[0];
       y3=sdat.data[1];
       x3=sdat.time[1];
     }
    
     k=( (3*(x1*y1+x2*y2+x3*y3)-(x1+x2+x3)*(y1+y2+y3))/(3*(x1*x1+x2*x2+x3*x3)-(x1+x2+x3)*(x1+x2+x3)) );
     b=( (y1+y2+y3) -k*(x1+x2+x3) )/3;

     uint16 y4 =k*(x3+SendWaterGageTimeFreq*1000)+b;
     
     return y4;
  }

//Ԥ������ʪ�ȴ�������һ����ֵ
float Soil_humidity_forecastValue(Soilhumidity_data_and_time sdat)
{
     double x1,x2,x3;
     double y1,y2,y3;
     double b,k;
     
     if( (sdat.time[2]>sdat.time[1])&&(sdat.time[1]>sdat.time[0]) )
     {
       y1=sdat.data[0];
       x1=sdat.time[0];
       y2=sdat.data[1];
       x2=sdat.time[1];
       y3=sdat.data[2];
       x3=sdat.time[2];

     
     }
     else if( (sdat.time[0]>sdat.time[2])&&(sdat.time[2]>sdat.time[1]) )
     {
       y1=sdat.data[1];
       x1=sdat.time[1];
       y2=sdat.data[2];
       x2=sdat.time[2];
       y3=sdat.data[0];
       x3=sdat.time[0];
     }
     else
     {
       y1=sdat.data[2];
       x1=sdat.time[2];
       y2=sdat.data[0];
       x2=sdat.time[0];
       y3=sdat.data[1];
       x3=sdat.time[1];
     }
    
     k=( (3*(x1*y1+x2*y2+x3*y3)-(x1+x2+x3)*(y1+y2+y3))/(3*(x1*x1+x2*x2+x3*x3)-(x1+x2+x3)*(x1+x2+x3)) );
     b=( (y1+y2+y3) -k*(x1+x2+x3) )/3;


     float y4 =k*(x3+SendSoilHumidityTimeFreq*1000)+b;
     
     return y4;

}

//���������Ķ�ʱ��
void start_Water_gage_timer()
{

    if(!SendWaterGageRemainTime)
     {
       SendWaterGageRemainTime= SendWaterGageTimeFreq - 60;//��������ǰ�Ķ�ʱ1min

     }
     if(SendWaterGageRemainTime > 65)//osal_start_timerEx max time is 65.535s
     {
       SendWaterGageRemainTime-= 65;
       osal_start_timerEx( p2p_test_TaskID,
                          p2p_test_START_WATER_GAGE_TIME_MSG_EVT, //�������ݣ��ٴ�����һ����ʱ��
                          65000);
     }
     else 
     {
       osal_start_timerEx(p2p_test_TaskID,
                          p2p_test_SEND_WATER_GAGE_MSG_EVT, 
                          SendWaterGageRemainTime * 1000);
      SendWaterGageRemainTime= 0;
     }

       return;

  
}

//��������ʪ�ȵĶ�ʱ��
void start_Soil_humidity_timer()
{

    if(!SendSoilHumidityRemainTime)
    {
      SendSoilHumidityRemainTime = SendSoilHumidityTimeFreq;
    }

    if(SendSoilHumidityRemainTime>65)//osal_start_timerEx max time is 65.535s
    {
      SendSoilHumidityRemainTime -= 65;
      osal_start_timerEx( p2p_test_TaskID,
                       p2p_test_START_SOIL_HUMIDITY_TIME_MSG_EVT,
                      65000 );
    }
    else
    {
       osal_start_timerEx( p2p_test_TaskID,
                      p2p_test_SEND_SOIL_HUMIDITY_FREQ_MSG_EVT,
                      SendSoilHumidityTimeFreq*1000 );
       SendSoilHumidityRemainTime = 0;
    }

      return;      

  }

//������ʪ�Ȳɼ��󾭴�����õ�����ֵ��Ϊʵ�ʵ�ģ��ֵ�����ǲο���ѹ�󣩣��Ա�洢��Ԥ��
float Soil_humidity_DtoA(uint16 data,uint16 vcc)
  {
    float x =( (1.25*data*vcc/8191)/8191);
    return x;
  }

/*********************************************************************
 * NETWORK LAYER CALLBACKS
 */

/*********************************************************************
 * PUBLIC FUNCTIONS
 */

/*********************************************************************
 * @fn      p2p_test_Init
 *
 * @brief   Initialization function for the Generic App Task.
 *          This is called during initialization and should contain
 *          any application specific initialization (ie. hardware
 *          initialization/setup, table initialization, power up
 *          notificaiton ... ).
 *
 * @param   task_id - the ID assigned by OSAL.  This ID should be
 *                    used to send messages and set timers.
 *
 * @return  none
 */
void p2p_test_Init( byte task_id )
{  
  p2p_test_TaskID = task_id;
  p2p_test_NwkState = DEV_INIT;
  p2p_test_TransID = 0;
//zyq add
  SendRainCountFreq = 1;
  RainCountNum = 0;  
  SendRainTimeFreq = 1;//product unit= 1 minute test unit=1 second
  SendRainRemainTime = 0;
  SendSoilHumidityTimeFreq = 5;
  SendSoilHumidityRemainTime = 0;  
  SendAccelerometerTimeFreq=1;
  SendAccelerometerRemainTime=0;
  SendVccValueTimeFreq   = 1;
  SendVccValueRemainTime = 0;
  
  SendWaterGageTimeFreq = 1*60;//��λ s
  SendWaterGageRemainTime=0;
  
  //select watergage type;
  WaterGageUnit=Default_Water_Gage;
  //select soil type:0--Clay_Soil,1--Loam_Soil,2--Sand_Soil.init is Clay_Soil
  SOIL_TYPE = 0;
//  SerialNumber = 0;
  
//�Լ���д
  //��ʼ��
  Water_gage_SerialNumber = 0;
  Water_gage_time = 1*60;
  Water_gage_forValue=0;

  no_charge_flag = 0;
  water_gage_on = 0;
  CheckWaterGageChargeTimeFreq =60; // 1min
  
  Water_gage_err_a = 10;  //10mm
  Water_gage_err_b = 50;  //50mm
  Water_gage_err_c = 100; //100mm
  
  Soil_humidity_SerialNumber = 0;
  Soil_humidity_time = 5*60;
  Soil_humidity_forValue=0;
  
  relation_done =0;
  acceptance = 1;
  
//δ�õ� 
   SoilHumidityFlag=0;
   RainFlag=0;
   WaterGageFlag=0;
   
   ARM_ID=0x00;
   Zigbee_ID=0x00;
   RES=0x00;
   
   Head_Map=(struct RelationMap_t *)osal_msg_allocate(sizeof(struct RelationMap_t));//init relation map
   Head_Map->addr16=0x0000;
   Head_Map->Zigbee_id=Zigbee_ID;
   Head_Map->next=NULL;
   Tail_Map=Head_Map;
   FlagMap=0x0000;
   //osal_msg_deallocate((uint8 *)Head_Map);
   // NodeId = 17;
   //NodeId = 32;
   //NodeId = 51;
   //NodeId = 68 ;
   //NodeId = 85 ;
   // Device hardware initialization can be added here or in main() (Zmain.c).
   // If the hardware is application specific - add it here.
   // If the hardware is other parts of the device add it in main().

  p2p_test_DstAddr.addrMode = (afAddrMode_t)Addr16Bit;//must't be modify in other
  p2p_test_DstAddr.endPoint = p2p_test_ENDPOINT;
  p2p_test_DstAddr.addr.shortAddr = 0x0000;

  // Fill out the endpoint description.
  p2p_test_epDesc.endPoint = p2p_test_ENDPOINT;
  p2p_test_epDesc.task_id = &p2p_test_TaskID;
  p2p_test_epDesc.simpleDesc
            = (SimpleDescriptionFormat_t *)&p2p_test_SimpleDesc;
  p2p_test_epDesc.latencyReq = noLatencyReqs;

  // Register the endpoint description with the AF
  afRegister( &p2p_test_epDesc );
  
  //P1_0 is the driver of uart1 
  P1SEL&=~(0x01);  //uart1 enable drive P1_0
  P1DIR |=(0x01);   //P1_0 output
  
  P2SEL&=~(0x01);  //uart1 enable drive P2_0
  P2DIR |=(0x01);   //P2_0 output
  P2_0=0;
 
  P1SEL&=~(0x02);  // P1_1
  P1DIR |=(0x02);   //P1_1 output
  P1_1=0;
  //P0SEL &=~ (0x30);
  //P0DIR &=~ (0x30);
  // Register for all key events - This app will handle all key events
  //RegisterForKeys( p2p_test_TaskID );
  /* 
  P2SEL &= ~(0x01);  //LED general-- test purpose
  P2DIR |= (0x01);   //LED output-- test purpose
  P2_0=1;            //LED brig.hten-- test purpose
  */ 
  
  //p1.3 -- general -- input -- pullup -- FallEdge
  OpenP1Interrupt(PIN_3, FUN_SELECT_GENERAL, DIRECTION_INPUT, INPUT_MODE_PULLUP, FALL_EDGE); 
  RegisterP1Interrupt(PIN_3, p2p_test_TaskID);
  StartP1Interrupt(PIN_3);   
  SPIMgr_RegisterTaskID(p2p_test_TaskID);//for uart recv


  // Update the display
  //#if defined ( LCD_SUPPORTED )
  //    HalLcdWriteString( "p2p_test", HAL_LCD_LINE_1 );
  //#endif

  ZDO_RegisterForZDOMsg( p2p_test_TaskID, End_Device_Bind_rsp );
  ZDO_RegisterForZDOMsg( p2p_test_TaskID, Match_Desc_rsp );
}

/*********************************************************************
 * @fn      p2p_test_ProcessEvent
 *
 * @brief   Generic Application Task event processor.  This function
 *          is called to process all events for the task.  Events
 *          include timers, messages and any other user defined events.
 *
 * @param   task_id  - The OSAL assigned task ID.
 * @param   events - events to process.  This is a bit map and can
 *                   contain more than one event.
 *
 * @return  none
 */
UINT16 p2p_test_ProcessEvent( byte task_id, UINT16 events )
{
  afIncomingMSGPacket_t *MSGpkt;
  afDataConfirm_t *afDataConfirm;

#if DEBUG
  uint8 x1 = 17;
  uint8 x2 = 34;
  uint8 x3 = 51;
  uint8 x4 = 68;
  uint8 x5 = 85;
  uint8 x6 = 102;
  uint8 x7 = 119;
  uint8 x8 = 136;
  uint8 x9 = 153;
  uint8 x10 = 170;
  
#endif
  
  // Data Confirmation message fields
  byte sentEP;
  ZStatus_t sentStatus;
  byte sentTransID;       // This should match the value sent
  
  if ( events & SYS_EVENT_MSG )
  {
    MSGpkt = (afIncomingMSGPacket_t *)osal_msg_receive( p2p_test_TaskID );
    while ( MSGpkt )
    {
      switch ( MSGpkt->hdr.event )
      {
        case ZDO_CB_MSG:
          p2p_test_ProcessZDOMsgs( (zdoIncomingMsg_t *)MSGpkt );
          break;

        case KEY_CHANGE:
          // p2p_test_HandleKeys( ((keyChange_t *)MSGpkt)->state, ((keyChange_t *)MSGpkt)->keys );
          break;
        case CMD_SERIAL_MSG: 
          p2p_test_RecvFromUart( ((mtOSALSerialData_t *)MSGpkt)->msg ); 
          break;
        case P1_0_INTERRUPT:
          
          break;
        case P1_1_INTERRUPT:
          
          break;
        case P1_2_INTERRUPT:

          break;
        case P1_3_INTERRUPT:
          //HalUARTWrite(0,te,3);
          p2p_test_interrupt_rain(  ( (rain_t *)MSGpkt )->count  );          
          break;
        case P1_4_INTERRUPT:
          
          break;
        case P1_5_INTERRUPT:
          
          break;
        case P1_6_INTERRUPT:
          
          break;
        case P1_7_INTERRUPT:
          
          break;          
        case AF_DATA_CONFIRM_CMD:
          // This message is received as a confirmation of a data packet sent.
          // The status is of ZStatus_t type [defined in ZComDef.h]
          // The message fields are defined in AF.h
          afDataConfirm = (afDataConfirm_t *)MSGpkt;
          sentEP = afDataConfirm->endpoint;
          sentStatus = afDataConfirm->hdr.status;
          sentTransID = afDataConfirm->transID;
          (void)sentEP;
          (void)sentTransID;

          // Action taken when confirmation is received.
          if ( sentStatus != ZSuccess )
          {
            // The data wasn't delivered -- Do something
          }
          break;

        case AF_INCOMING_MSG_CMD:
          p2p_test_MessageMSGCB( MSGpkt );
          //READ_TEST( MSGpkt );//DONG
            
 //         HalLedSet( HAL_LED_1, HAL_LED_MODE_ON );
  //        MicroWait( 62500 );
  //        MicroWait( 62500 );
   //       HalLedSet( HAL_LED_1, HAL_LED_MODE_OFF );
          break;

        case ZDO_STATE_CHANGE:
          p2p_test_NwkState = (devStates_t)(MSGpkt->hdr.status);

        //����������ɹ�
          if(p2p_test_NwkState ==DEV_END_DEVICE)
          {  
          osal_start_timerEx( p2p_test_TaskID,
                            p2p_test_SEND_MAINTAIN_MSG_EVT,
                            1000 ); 
#if DEBUG          
          HalUARTWrite(0,&x1, sizeof(x1));
#endif
          }
          //���������ʧ�ܣ���pan�ϵ磩
          else if(p2p_test_NwkState ==DEV_INIT)
          {
            osal_stop_timerEx(p2p_test_TaskID, 
                              p2p_test_SEND_WATER_GAGE_MSG_EVT);
            osal_stop_timerEx(p2p_test_TaskID, 
                              p2p_test_CHECK_WATER_GAGE_CHARGE_MSG_EVT);
            //p2p_test_Init(p2p_test_TaskID);//���Ӵ˾䣬֮ǰ�������Ա���
          
#if DEBUG          
          HalUARTWrite(0,&x2, sizeof(x2));
#endif    
          }      
          //pan����
          else if(p2p_test_NwkState ==DEV_ZB_COORD)
          {
               osal_start_timerEx( p2p_test_TaskID,
                            p2p_test_SEND_MAINTAIN_MSG_EVT,
                            1000 );    
#if DEBUG          
          HalUARTWrite(0,&x3, sizeof(x3));
#endif               
          }

#if DEBUG  
          else if(p2p_test_NwkState ==DEV_HOLD)   
            HalUARTWrite(0,&x4, sizeof(x4)); 
          else if(p2p_test_NwkState ==DEV_NWK_DISC)   
            HalUARTWrite(0,&x5, sizeof(x5));   
          else if(p2p_test_NwkState ==DEV_NWK_JOINING)   
            HalUARTWrite(0,&x6, sizeof(x6));
          else if(p2p_test_NwkState ==DEV_NWK_REJOIN)   
            HalUARTWrite(0,&x7, sizeof(x7)); 
          else if(p2p_test_NwkState ==DEV_END_DEVICE_UNAUTH)   
            HalUARTWrite(0,&x8, sizeof(x8));   
          else if(p2p_test_NwkState ==DEV_COORD_STARTING)   
            HalUARTWrite(0,&x9, sizeof(x9));      
          else if(p2p_test_NwkState ==DEV_NWK_ORPHAN)   
            HalUARTWrite(0,&x10, sizeof(x10));           
#endif 
          break;

        default:
          break;
      }

      // Release the memory
      osal_msg_deallocate( (uint8 *)MSGpkt );

      // Next
      MSGpkt = (afIncomingMSGPacket_t *)osal_msg_receive( p2p_test_TaskID );
    }

    // return unprocessed events
    return (events ^ SYS_EVENT_MSG);
  }
  
  if ( events & p2p_test_SEND_MAINTAIN_MSG_EVT)
  {
    p2p_test_SendRelationPkt();
    //p2p_test_SendResetRelativeTime();
    // return unprocessed events
    return (events ^ p2p_test_SEND_MAINTAIN_MSG_EVT);    
  }

  if ( events & p2p_test_SEND_RAIN_FREQ_MSG_EVT)
  {
    p2p_test_SendRainTimeFreqAndRequire( FREQ );
    // return unprocessed events
    return (events ^ p2p_test_SEND_RAIN_FREQ_MSG_EVT);    
  }
  
  if ( events & p2p_test_SEND_SOIL_HUMIDITY_FREQ_MSG_EVT )
  {
    p2p_test_SendSoilHumidityTimeFreqAndRequire( FREQ );
    // return unprocessed events
    return (events ^ p2p_test_SEND_SOIL_HUMIDITY_FREQ_MSG_EVT);
  }  
  

  
  if ( events & p2p_test_SEND_VCC_VALUE_FREQ_MSG_EVT )
  {
    p2p_test_Send_VCC_VALUE( FREQ );
    // return unprocessed events
    return (events ^ p2p_test_SEND_VCC_VALUE_FREQ_MSG_EVT);
  }  
  
  if( events & p2p_test_SEND_WATER_GAGE_MSG_EVT )
  {
    p2p_test_Send_Water_Gage(FREQ,WaterGageUnit);
    return (events ^ p2p_test_SEND_WATER_GAGE_MSG_EVT);
  }
  
  if ( events &  p2p_test_SEND_ACCELEROMETER_FREQ_MSG_EVT )
  {
    p2p_test_SendAccelerometerTimeFreqAndRequire( FREQ );
    // return unprocessed events
    return (events ^ p2p_test_SEND_ACCELEROMETER_FREQ_MSG_EVT);
  } 
  
   //�Լ���д
  //�ʺ�SendWaterGageTimeFreq����65s�����
  if (events & p2p_test_START_WATER_GAGE_TIME_MSG_EVT)
  {
    start_Water_gage_timer();
   return (events ^ p2p_test_START_WATER_GAGE_TIME_MSG_EVT);
  }
  
  if (events &  p2p_test_START_SOIL_HUMIDITY_TIME_MSG_EVT)
  {
    start_Soil_humidity_timer();
   return (events ^  p2p_test_START_SOIL_HUMIDITY_TIME_MSG_EVT);
  }

  if (events &  p2p_test_CHECK_WATER_GAGE_CHARGE_MSG_EVT)
  {
    check_water_gage_charge();
   return (events ^  p2p_test_CHECK_WATER_GAGE_CHARGE_MSG_EVT);
  }  
  
 
   
  // Discard unknown events
  return 0;
}

/*********************************************************************
 * Event Generation Functions
 */
/*********************************************************************
 * @fn      p2p_test_ProcessZDOMsgs()
 *
 * @brief   Process response messages
 *
 * @param   none
 *
 * @return  none
 */
void p2p_test_ProcessZDOMsgs( zdoIncomingMsg_t *inMsg )
{ 
  switch ( inMsg->clusterID )
  {
    case End_Device_Bind_rsp:
      if ( ZDO_ParseBindRsp( inMsg ) == ZSuccess )
      {
        // Light LED
        HalLedSet( HAL_LED_4, HAL_LED_MODE_ON );
      }
#if defined(BLINK_LEDS)
      else
      {
        // Flash LED to show failure
        HalLedSet ( HAL_LED_4, HAL_LED_MODE_FLASH );
      }
#endif
      break;

    case Match_Desc_rsp:
      {
        ZDO_ActiveEndpointRsp_t *pRsp = ZDO_ParseEPListRsp( inMsg );
        if ( pRsp )
        {
          if ( pRsp->status == ZSuccess && pRsp->cnt )
          {
            p2p_test_DstAddr.addrMode = (afAddrMode_t)Addr16Bit;
            p2p_test_DstAddr.addr.shortAddr = pRsp->nwkAddr;
            // Take the first endpoint, Can be changed to search through endpoints
            p2p_test_DstAddr.endPoint = pRsp->epList[0];

            // Light LED
            HalLedSet( HAL_LED_4, HAL_LED_MODE_ON );
          }
          osal_mem_free( pRsp );
        }
      }
      break;
  }
}



/*********************************************************************
 * LOCAL FUNCTIONS
 */

/*********************************************************************
 * @fn      p2p_test_MessageMSGCB
 *
 * @brief   Data message processor callback.  This function processes
 *          any incoming data - probably from other devices.  So, based
 *          on cluster ID, perform the intended action.
 *
 * @param   none
 *
 * @return  none
 */
void p2p_test_MessageMSGCB( afIncomingMSGPacket_t *pkt )
{
  uint16 temp_shortaddr;
  switch ( pkt->clusterId )
  {
    case p2p_test_CLUSTERID:
      // "the" message
      //p2p_test_SendToUart((uint8*)pkt->cmd.Data, pkt->cmd.DataLength);
      //HalUARTWrite( 0, (uint8*)pkt->cmd.Data, pkt->cmd.DataLength );
      break;
    case p2p_test_108ID:
      p2p_test_recv_108clusterId(pkt->cmd.Data, pkt->cmd.DataLength);
      //SendRainCountFreq=(pkt->cmd.Data)[0];
      break;
    case p2p_test_RelationMsg:
      temp_shortaddr=pkt->srcAddr.addr.shortAddr;
      //printf short_addr
     // p2p_test_SendToUart((uint8 *)&temp_shortaddr,sizeof(temp_shortaddr));
     // HalUARTWrite(0,(uint8 *)&temp_shortaddr,sizeof(temp_shortaddr));
      p2p_test_recv_RelationMsgclusterId(pkt->cmd.Data,pkt->cmd.DataLength,temp_shortaddr);
      break;
    
  }
}


/*********************************************************************
 * @fn      p2p_test_SendTheMessage
 *
 * @brief   Send "the" message.
 *
 * @param   none
 *
 * @return  none
 */
/*
void p2p_test_SendTheMessage( void )
{
   //char p2p_msg[] = "Hello World ";
   if ( AF_DataRequest( &p2p_test_DstAddr, &p2p_test_epDesc,
                       p2p_test_CLUSTERID,
                       6,
                       (byte *)&p2p_msg,
                       &p2p_test_TransID,
                       AF_DISCV_ROUTE, AF_DEFAULT_RADIUS ) == afStatus_SUCCESS )

  {
    // Successfully requested to be sent.  
//    HalUARTWrite( 0,  (uint8 *)p2p_msg, (byte)osal_strlen( p2p_msg ) + 1);

  } 
  
  else
  {
    // Error occurred in request to send.
  }
}
*/

/*********************************************************************
 * @fn      p2p_test_recv_108clusterId
 *
 * @brief   
 *
 * @param   none
 *
 * @return  none
 */
void p2p_test_recv_108clusterId(uint8 *pkt, uint8 length)
{
  AppHead_t *AppHead = (AppHead_t *)pkt;
  //AppHead->AckRequire;
  if(AppHead->type == TYPE_SENSOR ||(AppHead->type == TYPE_ACK && AppHead->TypeCode==TYPE_ACK_UP) )
  {
    //if(AppHead->TypeCode == TYPE_CODE_SENSOR_RAIN)//may be is not need,TYPE_SENSOR all to UART 
    //{
      p2p_test_SendToUart(pkt, length);
      return;
    //}
  }
  else if(AppHead->type == TYPE_COMMAND)
  {
    uint8 temp_arm_id,temp_zigbee_id;
    temp_arm_id=(pkt[4]&0x0f);
    temp_zigbee_id=(pkt[5]&0xf0)>>4;
    uint16 SerialNumber =BUILD_UINT16(AppHead->sn[1],AppHead->sn[0]);
    //uint16 SerialNumber =BUILD_UINT16(pkt[3],pkt[2]);
    
    if(ARM_ID==temp_arm_id && Zigbee_ID==temp_zigbee_id)
    {
    //  if(AppHead->TypeCode == TYPE_CODE_COMMAND_MODIFY_K)
  //    {
        uint8 sensor_type = pkt[6];
        uint16 freq = BUILD_UINT16(pkt[7], 0x00);
        AppHeadNodeId_t *AppHeadNodeId=(AppHeadNodeId_t *)osal_msg_allocate(sizeof(AppHeadNodeId_t));
        //fill_AppHead((AppHead_t *)&AppHeadNodeId->AppHead,ACK_NO, MAIN_VERSION, SUB_VERSION,TYPE_ACK,TYPE_ACK_UP);
        fill_AppHead_sn((AppHead_t *)&AppHeadNodeId->AppHead,ACK_NO, MAIN_VERSION, SUB_VERSION,TYPE_ACK,TYPE_ACK_UP, SerialNumber);

        AppHeadNodeId->NodeId.r=RES;
        AppHeadNodeId->NodeId.ARM_id=ARM_ID;
        AppHeadNodeId->NodeId.Zigbee_id=Zigbee_ID;//
      //  uint16 freq=(uint16)pkt[7]
        
        switch (sensor_type)
        {
          
        case COMMAND_TYPE_RAIN:               //����Kֵ
          if( (freq & 0x0080) == 0 )          //��������7λ
            SendRainTimeFreq = freq;
          else
          {
            freq = freq &0x007F;
            SendRainTimeFreq = freq*60 ;
          }
          //SendRainTimeFreq = freq;
          osal_stop_timerEx(p2p_test_TaskID, p2p_test_SEND_RAIN_FREQ_MSG_EVT);
          SendRainRemainTime = 0;//send at once
          p2p_test_SendRainTimeFreqAndRequire(FREQ);   
          AppHeadNodeId->NodeId.sensor_type= RAIN_ID ;
          SendMsg((uint8 *)AppHeadNodeId,sizeof(AppHeadNodeId_t), p2p_test_DstAddr, AF_DISCV_ROUTE,p2p_test_108ID);
          break;
          
        case COMMAND_TYPE_RAIN_KVALUE:         //����Nֵ
          SendRainCountFreq = freq;
          RainCountNum = 0;//reset  
          AppHeadNodeId->NodeId.sensor_type= RAIN_ID ;
          SendMsg((uint8 *)AppHeadNodeId,sizeof(AppHeadNodeId_t), p2p_test_DstAddr, AF_DISCV_ROUTE,p2p_test_108ID);
          break;
          
        case COMMAND_TYPE_SOIL_HUMIDITY:       //����ʪ��Kֵ

          SendSoilHumidityTimeFreq = freq*60;
          osal_stop_timerEx(p2p_test_TaskID, p2p_test_SEND_SOIL_HUMIDITY_FREQ_MSG_EVT);
          SendSoilHumidityRemainTime = 0;//send at once
          p2p_test_SendSoilHumidityTimeFreqAndRequire(FREQ); 
          AppHeadNodeId->NodeId.sensor_type= SOIL_ID ;
          SendMsg((uint8 *)AppHeadNodeId,sizeof(AppHeadNodeId_t), p2p_test_DstAddr, AF_DISCV_ROUTE,p2p_test_108ID);
          break;
          
        case COMMAND_TYPE_VIBRATIO:             //��Kֵ
          SendAccelerometerTimeFreq=freq*60;
          osal_stop_timerEx(p2p_test_TaskID, p2p_test_SEND_ACCELEROMETER_FREQ_MSG_EVT);
          SendAccelerometerRemainTime = 0;      //send at once
          AppHeadNodeId->NodeId.sensor_type= EARTHQUAKE_ID ;
          p2p_test_SendAccelerometerTimeFreqAndRequire(FREQ);
          SendMsg((uint8 *)AppHeadNodeId,sizeof(AppHeadNodeId_t), p2p_test_DstAddr, AF_DISCV_ROUTE,p2p_test_108ID);
          break;
          
        case COMMAND_TYPE_WATER_GAGE:            //ˮλKֵ

          SendWaterGageTimeFreq= freq*60;
          //osal_stop_timerEx(p2p_test_TaskID, p2p_test_SEND_WATER_GAGE_MSG_EVT);
          //SendWaterGageRemainTime=0;
          AppHeadNodeId->NodeId.sensor_type= WATER_GAGE_ID ;
          //p2p_test_Send_Water_Gage(FREQ,WaterGageUnit);
          SendMsg((uint8 *)AppHeadNodeId,sizeof(AppHeadNodeId_t), p2p_test_DstAddr, AF_DISCV_ROUTE,p2p_test_108ID);
#if DEBUG
          HalUARTWrite_uint16(SendWaterGageTimeFreq);
#endif             
          break;
          
        case COMMAND_TYPE_WATER_HIGHTYPE:          //ˮλ����������
          WaterGageUnit = BUILD_UINT16(pkt[7],0x00 );
          //osal_stop_timerEx(p2p_test_TaskID, p2p_test_SEND_WATER_GAGE_MSG_EVT);
          //SendWaterGageRemainTime=0;
          AppHeadNodeId->NodeId.sensor_type= WATER_GAGE_ID ;
          //p2p_test_Send_Water_Gage(FREQ,WaterGageUnit);
          SendMsg((uint8 *)AppHeadNodeId,sizeof(AppHeadNodeId_t), p2p_test_DstAddr, AF_DISCV_ROUTE,p2p_test_108ID);
#if DEBUG
          HalUARTWrite_uint16(WaterGageUnit);
#endif          
          break;
          
        case COMMAND_TYPE_WATER_T:                  //ˮλ������Ӧ�ɼ��������Ӽ��Tȡֵ
          Water_gage_time = BUILD_UINT16(pkt[7],0x00 )*60;   
          AppHeadNodeId->NodeId.sensor_type= WATER_GAGE_ID ;
          SendMsg((uint8 *)AppHeadNodeId,sizeof(AppHeadNodeId_t), p2p_test_DstAddr, AF_DISCV_ROUTE,p2p_test_108ID);
#if DEBUG
          HalUARTWrite(0,&pkt[7], sizeof(pkt[7]));
#endif
          break;
          
        case COMMAND_TYPE_WATER_EDGE_A:              //ˮλ������Ӧ�߽�ȡֵA
          Water_gage_err_a = pkt[7];
          AppHeadNodeId->NodeId.sensor_type= WATER_GAGE_ID ;
          SendMsg((uint8 *)AppHeadNodeId,sizeof(AppHeadNodeId_t), p2p_test_DstAddr, AF_DISCV_ROUTE,p2p_test_108ID);
#if DEBUG
          HalUARTWrite(0,&Water_gage_err_a, sizeof(Water_gage_err_a));
#endif
          
          break;
          
        case COMMAND_TYPE_WATER_EDGE_B:               //ˮλ������Ӧ�߽�ȡֵB
          Water_gage_err_b = pkt[7];
          AppHeadNodeId->NodeId.sensor_type= WATER_GAGE_ID ;
          SendMsg((uint8 *)AppHeadNodeId,sizeof(AppHeadNodeId_t), p2p_test_DstAddr, AF_DISCV_ROUTE,p2p_test_108ID);          
#if DEBUG
          HalUARTWrite(0,&Water_gage_err_b, sizeof(Water_gage_err_b));
#endif
          break;
          
        case COMMAND_TYPE_WATER_EDGE_C:               //ˮλ������Ӧ�߽�ȡֵC
          Water_gage_err_c = pkt[7];
          AppHeadNodeId->NodeId.sensor_type= WATER_GAGE_ID ;
          SendMsg((uint8 *)AppHeadNodeId,sizeof(AppHeadNodeId_t), p2p_test_DstAddr, AF_DISCV_ROUTE,p2p_test_108ID);          
#if DEBUG
          HalUARTWrite(0,&Water_gage_err_c, sizeof(Water_gage_err_c));
#endif
          break;
          
        case COMMAND_TYPE_ZIGBEE_RESTART:             //zigbee����������
          {
          AppHeadNodeId->NodeId.sensor_type= WATER_GAGE_ID ;
          SendMsg((uint8 *)AppHeadNodeId,sizeof(AppHeadNodeId_t), p2p_test_DstAddr, AF_DISCV_ROUTE,p2p_test_108ID);   
        
/*          Zigbee_Restart_Command_t *pkt_zst = (Zigbee_Restart_Command_t *)pkt;
       
          WaterGageUnit = pkt_zst->water_gage_type;
          SendWaterGageTimeFreq = pkt_zst-> water_gage_freq;
          Water_gage_time = pkt_zst-> water_gage_T;
          Water_gage_err_a = pkt_zst-> water_gage_A;
          Water_gage_err_b = pkt_zst-> water_gage_B;
          Water_gage_err_c = pkt_zst-> water_gage_C;  
*/
         // osal_stop_timerEx(p2p_test_TaskID, p2p_test_SEND_WATER_GAGE_MSG_EVT);
          WaterGageUnit = BUILD_UINT16(pkt[8],pkt[7]);
          SendWaterGageTimeFreq = BUILD_UINT16(pkt[10],pkt[9])*60;
          Water_gage_time = BUILD_UINT16(pkt[12],pkt[11])*60;
          Water_gage_err_a = pkt[13];
          Water_gage_err_b = pkt[14];
          Water_gage_err_c = pkt[15];
        
#if DEBUG
          HalUARTWrite_uint16(WaterGageUnit);
          HalUARTWrite_uint16(SendWaterGageTimeFreq);
          HalUARTWrite_uint16(Water_gage_time);
          HalUARTWrite(0,&Water_gage_err_a, sizeof(Water_gage_err_a));        
          HalUARTWrite(0,&Water_gage_err_b, sizeof(Water_gage_err_b));          
          HalUARTWrite(0,&Water_gage_err_c, sizeof(Water_gage_err_c));
#endif   
          }
          break ;
          
        case COMMAND_TYPE_ACCEPTANCE:
          acceptance = pkt[7] ;
          AppHeadNodeId->NodeId.sensor_type= WATER_GAGE_ID ;
          SendMsg((uint8 *)AppHeadNodeId,sizeof(AppHeadNodeId_t), p2p_test_DstAddr, AF_DISCV_ROUTE,p2p_test_108ID);          
#if DEBUG
          HalUARTWrite(0,&acceptance, sizeof(acceptance));
#endif
          break;
          
        default :
          break;
         
        }
        
        osal_msg_deallocate((uint8 *)AppHeadNodeId); 
        return;
    }
      /*
        else if(AppHead->TypeCode == TYPE_CODE_COMMAND_MODIFY_N)
        {
          uint8 sensor_type = pkt[6];
          if(sensor_type == TYPE_CODE_SENSOR_RAIN)
          {
            SendRainCountFreq = pkt[7];
            RainCountNum = 0;//reset        
          }
          return;
        }
        else if(AppHead->TypeCode == TYPE_CODE_COMMAND_REQUIRE)
        {
          uint8 sensor_type = pkt[6];
          if(sensor_type == TYPE_CODE_SENSOR_RAIN)
          {
            p2p_test_SendRainTimeFreqAndRequire(REQUIRE);
          }
          else if(sensor_type == TYPE_CODE_SENSOR_SOIL_HUMIDITY )
          {
            SOIL_TYPE = pkt[7];
            p2p_test_SendSoilHumidityTimeFreqAndRequire(REQUIRE);
          }   
           else if(sensor_type == TYPE_CODE_SENSOR_READ_VCC)
         {
          p2p_test_Send_VCC_VALUE(REQUIRE);
         }
          return;
        }     
        else if(AppHead->TypeCode == TYPE_CODE_COMMAND_SENSOR_STOP_EVT)
        {
          uint8 sensor_type = pkt[6];
          if (sensor_type ==  TYPE_CODE_SENSOR_RAIN)
          {
           osal_stop_timerEx(p2p_test_TaskID, p2p_test_SEND_RAIN_FREQ_MSG_EVT);
           SendRainRemainTime = 0;//keep next send at once
          } 
          else if(sensor_type == TYPE_CODE_SENSOR_SOIL_HUMIDITY)
          {
           osal_stop_timerEx(p2p_test_TaskID, p2p_test_SEND_SOIL_HUMIDITY_FREQ_MSG_EVT );
           SendSoilHumidityRemainTime = 0;   //keep next send at once
          }
          else if(sensor_type == TYPE_CODE_SENSOR_READ_VCC)
          {
          osal_stop_timerEx(p2p_test_TaskID, p2p_test_SEND_VCC_VALUE_FREQ_MSG_EVT);
          SendVccValueRemainTime = 0;       //keep next send at once
          }
        }
    }*/
  }
     
     
   /* else if(AppHead->type == TYPE_MAINTAIN)
    {
      if((AppHead->TypeCode == TYPE_CODE_MAINTAIN_RESET_TIME) || (AppHead->TypeCode == TYPE_CODE_MAINTAIN_RELATION_1))
      {
        p2p_test_SendToUart(pkt, length);
        return;
      }
    */
 /* else if(AppHead->type == TYPE_ZIGBEE_RESTART_COMMAND)
  {
    uint8 temp_arm_id,temp_zigbee_id;
    temp_arm_id=(pkt[4]&0x0f);
    temp_zigbee_id=(pkt[5]&0xf0)>>4;
    uint16 SerialNumber =BUILD_UINT16(AppHead->sn[1],AppHead->sn[0]);
    //uint16 SerialNumber =BUILD_UINT16(pkt[3],pkt[2]);
    
    if(ARM_ID==temp_arm_id && Zigbee_ID==temp_zigbee_id)
    {

   //     uint8 sensor_type = pkt[6];
  //      uint16 freq = BUILD_UINT16(pkt[7], 0x00);
        AppHeadNodeId_t *AppHeadNodeId=(AppHeadNodeId_t *)osal_msg_allocate(sizeof(AppHeadNodeId_t));
        //fill_AppHead((AppHead_t *)&AppHeadNodeId->AppHead,ACK_NO, MAIN_VERSION, SUB_VERSION,TYPE_ACK,TYPE_ACK_UP);
        fill_AppHead_sn((AppHead_t *)&AppHeadNodeId->AppHead,ACK_NO, MAIN_VERSION, SUB_VERSION,TYPE_ACK,TYPE_ACK_UP, SerialNumber);

        AppHeadNodeId->NodeId.r=RES;
        AppHeadNodeId->NodeId.ARM_id=ARM_ID;
        AppHeadNodeId->NodeId.Zigbee_id=Zigbee_ID;
        AppHeadNodeId->NodeId.sensor_type= WATER_GAGE_ID ;
        SendMsg((uint8 *)AppHeadNodeId,sizeof(AppHeadNodeId_t), p2p_test_DstAddr, AF_DISCV_ROUTE,p2p_test_108ID);   
        
        Zigbee_Restart_Command_t *pkt_zst = (Zigbee_Restart_Command_t *)pkt;
      
        WaterGageUnit = pkt_zst->water_gage_type;
        SendWaterGageTimeFreq = pkt_zst-> water_gage_freq;
        Water_gage_time = pkt_zst-> water_gage_T ;
        Water_gage_err_a = pkt_zst-> water_gage_A;
        Water_gage_err_b = pkt_zst-> water_gage_B;
        Water_gage_err_c = pkt_zst-> water_gage_C;   
        
#if DEBUG
        HalUARTWrite_uint16(WaterGageUnit);
        HalUARTWrite(0,&Water_gage_err_a, sizeof(Water_gage_err_a));
        HalUARTWrite_uint16(SendWaterGageTimeFreq);
        HalUARTWrite(0,&Water_gage_err_b, sizeof(Water_gage_err_b));
        HalUARTWrite_uint16(Water_gage_time);
        HalUARTWrite(0,&Water_gage_err_c, sizeof(Water_gage_err_c));
#endif        
        osal_msg_deallocate((uint8 *)AppHeadNodeId);
    }
    return ;
  }*/

  else if(AppHead->type == TYPE_REPORT)
  {
  }
  else if(AppHead->type == TYPE_ACK)
  {
  }
  // osal_msg_deallocate((uint8 *)pkt); 
}

/*********************************************************************
 * @fn      p2p_test_recv_RelationMsgclusterId
 *
 * @brief   
 *
 * @param   none
 *
 * @return  none
 */
void p2p_test_recv_RelationMsgclusterId(uint8 *pkt,uint8 length,uint16 srcaddr)
{
  AppHead_t *AppHead = (AppHead_t *)pkt;
  uint16 num;
  uint8 temp_Zigbee_ID;
  uint8 temp_ARM_ID;
  uint8 temp_ACK;
  uint8 SendOption;
  struct RelationMap_t *temp_map=NULL;
 // static uint8 acknum=0;
  //coord print
 // SendMsg((uint8 *)pkt, length, p2p_test_DstAddr, AF_DISCV_ROUTE,p2p_test_RelationMsg);
  if(AppHead->type==TYPE_MAINTAIN)//coord receive fronm commom node relation Msg Request
  {
    if(AppHead->TypeCode==RELATION_MSG_UP)
    {
      num=BUILD_UINT16(pkt[5],pkt[4]);
      SendMsg((uint8 *)pkt, length, p2p_test_DstAddr, AF_DISCV_ROUTE,p2p_test_RelationMsg);
   /*   if(AppHead->AckRequire)
      {
        SendOption = AF_DISCV_ROUTE|AF_ACK_REQUEST;
      }
      else
      {
        SendOption = AF_DISCV_ROUTE;
      } */
      AppHeadNodeId_t *AppHeadNodeId=(AppHeadNodeId_t *)osal_msg_allocate(sizeof(AppHeadNodeId_t));
      SendOption = AF_DISCV_ROUTE;
      if(0==num)
      {
        temp_ACK=ACK_YES;
        //SendMsg((uint8 *)pkt, length, p2p_test_DstAddr, AF_DISCV_ROUTE,p2p_test_RelationMsg);
        fill_AppHead((AppHead_t *)&AppHeadNodeId->AppHead, temp_ACK, MAIN_VERSION, SUB_VERSION, TYPE_ACK,RELATION_MSG_DOWN);
        if(Zigbee_ID!=0)
         {
           temp_Zigbee_ID=search_RelationMap(srcaddr);//check srcaddr is in the RelationMap
          //  HalUARTWrite(0,(uint8 *)&temp_Zigbee_ID,sizeof(temp_Zigbee_ID));
          if(0==temp_Zigbee_ID)
          {
            uint8 i;
            uint16 temp_flag;
            temp_flag=FlagMap;
            uint16 t;
            for(i=1;i<16;i++)
            {
              t=(temp_flag>>(i-1))&0x0001;
              if(t==0)
                break;
            }
            FlagMap=ADDFLAG16(FlagMap,i);
            temp_Zigbee_ID=i;
            insert_RelationMap(temp_map,srcaddr,i); 
          }
          AppHeadNodeId->NodeId.r=RES;
          AppHeadNodeId->NodeId.ARM_id=ARM_ID;
          AppHeadNodeId->NodeId.Zigbee_id= temp_Zigbee_ID;//
          AppHeadNodeId->NodeId.sensor_type=0x00;
         // SendMsg((uint8 *)AppHeadNodeId,sizeof(AppHeadNodeId_t), p2p_test_DstAddr, AF_DISCV_ROUTE,p2p_test_RelationMsg);
          afAddrType_t p2p_test_DstAddr_temp;
          p2p_test_DstAddr_temp.addrMode = (afAddrMode_t)Addr16Bit;
          p2p_test_DstAddr_temp.endPoint = p2p_test_ENDPOINT;
          p2p_test_DstAddr_temp.addr.shortAddr = srcaddr;  
          AF_DataRequest( &p2p_test_DstAddr_temp, &p2p_test_epDesc,
                                   p2p_test_RelationMsg,
                                   sizeof(AppHeadNodeId_t),
                                   (uint8*)AppHeadNodeId,
                                   &p2p_test_TransID,
                                   SendOption, AF_DEFAULT_RADIUS);
          osal_msg_deallocate((uint8 *)AppHeadNodeId); 
        } 
      }
      else if(Zigbee_ID!=0 && num!=0)//num!=0,then send to uart
      {
        temp_ACK=ACK_YES;
        SendMsg((uint8 *)pkt, length, p2p_test_DstAddr, AF_DISCV_ROUTE,p2p_test_RelationMsg);
      }
      //fill_AppHead((AppHead_t *)&temp_DownAckMsg.AppHead,temp_ACK,MAIN_VERSION,SUB_VERSION,TYPE_ACK,RELATION_MSG_DOWN);

    }    
  }
  else if(AppHead->type==TYPE_ACK)//only common node receive form coord node's ACK RelationMsg
  { 
    //print something as flag
   // uint16 A=0xAAAA;
   // HalUARTWrite(0,(uint8 *)A,sizeof(A));
    if(AppHead->TypeCode==RELATION_MSG_DOWN)
    {
      temp_ARM_ID=pkt[4]&0x0f;
      temp_Zigbee_ID=(pkt[5]&0xf0)>>4;
      if(ARM_ID==0 && Zigbee_ID==0)
      {
        ARM_ID=temp_ARM_ID;
        Zigbee_ID=temp_Zigbee_ID;
       // acknum=1;
      }
      else if(Zigbee_ID!=0 && ARM_ID==temp_ARM_ID && Zigbee_ID==temp_Zigbee_ID)  //ARM_ID!=0,Zigbee_ID!=0
      { 
        if(relation_done == 0)//�������յ�ackӰ�����ݲɼ�ʱ���bug
        {
         osal_stop_timerEx( p2p_test_TaskID,p2p_test_SEND_MAINTAIN_MSG_EVT);
         p2p_test_StartDataSensorTimer();
         relation_done =1;
        }
      }
    }
  }
}
/*********************************************************************
 * @fn      p2p_test_RecvFromUart
 *
 * @brief   
 *
 * @param   none
 *
 * @return  none
 */
void p2p_test_RecvFromUart(uint8 *Msg)
{
  //Msg = 0xAA 0x55 LEN shortaddr0 shortaddr1 DATA (Not include check, add short addr)
  //temporarily not consider broadcast
  static uint8 ack_num=0;
  if((0x01==Msg[0])&&(0x03==Msg[1]))
  {
    //Msg = 0x01 0x03 LEN DATA 
  //temporarily not consider broadcast
       no_charge_flag = 0;
       WaterGageFlag=1;
       Water_Gage_t  temp_water_gage;
  //temp_water_gage.water_gage_type[0]=HI_UINT16(WaterGageUnit);
  //temp_water_gage.water_gage_type[1]=LO_UINT16(WaterGageUnit);   
       temp_water_gage.water_gage_value[0]=Msg[3];
       temp_water_gage.water_gage_value[1]=Msg[4];
       fill_AppHead((AppHead_t *)&temp_water_gage.AppHead, ACK_NO, MAIN_VERSION, SUB_VERSION, TYPE_SENSOR, TYPE_CODE_SENSOR_WATER_GAGE);
       fill_NodeId_time((NodeIdAndTime_t *)&temp_water_gage.NodeIdAndTime,ARM_ID,Zigbee_ID,WATER_GAGE_ID);
       SendMsg((uint8 *)&temp_water_gage, sizeof(temp_water_gage), p2p_test_DstAddr, AF_DISCV_ROUTE,p2p_test_108ID);
 
    
//�Լ���д
  
       uint16 temp_Water_gage_data = BUILD_UINT16(Msg[4], Msg[3]);
  //HalUARTWrite(0,(uint8 *)&(temp_water_gage.water_gage_value),sizeof(temp_water_gage.water_gage_value));
  //uint16 data = BUILD_UINT16(Msg[3], Msg[4]);
  //HalUARTWrite(0,(uint8*)&data, sizeof(data));
#if DEBUG
  //���ڲ���
     uint8 a1 =1;
     uint8 a2 =2;
     uint8 a3 =3;
     uint8 a4 =4;
#endif
 
     //��WaterGageUnit == 3ΪĬ������������ݼ�Ԥ��
     if(WaterGageUnit == 0)
     {
       Water_Gage_data_and_time.data[Water_gage_SerialNumber%3]=Water_gage_data_span - temp_Water_gage_data*10;
       Water_Gage_data_and_time.time[Water_gage_SerialNumber%3]= now;
#if DEBUG
      // HalUARTWrite(0,&a1, sizeof(a1));
#endif
     }
     else if(WaterGageUnit == 1)
     {
       Water_Gage_data_and_time.data[Water_gage_SerialNumber%3]=Water_gage_data_span - temp_Water_gage_data;
       Water_Gage_data_and_time.time[Water_gage_SerialNumber%3]= now;    
       //HalUARTWrite(0,&a2, sizeof(a2));
     }
     else if(WaterGageUnit == 2)
     {
       Water_Gage_data_and_time.data[Water_gage_SerialNumber%3]=temp_Water_gage_data*10;
       Water_Gage_data_and_time.time[Water_gage_SerialNumber%3]= now;
       //HalUARTWrite(0,&a3, sizeof(a3));       
     }
     else if(WaterGageUnit == 3)
     {
       Water_Gage_data_and_time.data[Water_gage_SerialNumber%3]=temp_Water_gage_data;
       Water_Gage_data_and_time.time[Water_gage_SerialNumber%3]= now;  
       //HalUARTWrite(0,&a4, sizeof(a4));
     }       
      // HalUARTWrite(0,(uint8*)&Water_Gage_data_and_time.time[0], sizeof(Water_Gage_data_and_time.time[0]));
      // HalUARTWrite(0,(uint8*)&Water_Gage_data_and_time.time[1], sizeof(Water_Gage_data_and_time.time[1]));
      // HalUARTWrite(0,(uint8*)&Water_Gage_data_and_time.time[2], sizeof(Water_Gage_data_and_time.time[2]));
       
     //  HalUARTWrite(0,(uint8*)& Water_Gage_data_and_time.data[Water_gage_SerialNumber%3], sizeof( Water_Gage_data_and_time.data[Water_gage_SerialNumber%3]));
       Water_gage_SerialNumber++;
  
  //����Ԥ��ֵѡ��ʱ��ʱ��
       if(Water_gage_SerialNumber >=4)
           {
            if(WaterGageUnit == 0)
            {
             Water_gage_err = ((Water_gage_data_span - temp_Water_gage_data*10) >Water_gage_forValue )? 
                ( (Water_gage_data_span - temp_Water_gage_data*10)- Water_gage_forValue) : 
                 (Water_gage_forValue -(Water_gage_data_span - temp_Water_gage_data*10));    
#if DEBUG
                 HalUARTWrite(0,&a1, sizeof(a1));
#endif
            }
            else if(WaterGageUnit == 1)
            {
             Water_gage_err = ((Water_gage_data_span - temp_Water_gage_data) >Water_gage_forValue )? 
                ( (Water_gage_data_span - temp_Water_gage_data)- Water_gage_forValue) : 
                 (Water_gage_forValue -(Water_gage_data_span - temp_Water_gage_data));                 
#if DEBUG
                 HalUARTWrite(0,&a2, sizeof(a2));
#endif
            }
            else if(WaterGageUnit == 2)
            {
             Water_gage_err = (temp_Water_gage_data*10 >Water_gage_forValue )? 
                (temp_Water_gage_data*10- Water_gage_forValue) : 
                 (Water_gage_forValue -temp_Water_gage_data*10);
#if DEBUG
                 HalUARTWrite(0,&a3, sizeof(a3));                 
#endif
            } 
            else if(WaterGageUnit == 3)
            {
             Water_gage_err = (temp_Water_gage_data >Water_gage_forValue )? 
                (temp_Water_gage_data- Water_gage_forValue) : 
                 (Water_gage_forValue -temp_Water_gage_data); 
#if DEBUG
                 HalUARTWrite(0,&a4, sizeof(a4));
#endif
            }     
            
#if DEBUG
            HalUARTWrite_uint16(Water_gage_err);
#endif
            
             if( Water_gage_err < Water_gage_err_a )
             {
               SendWaterGageTimeFreq += 2*Water_gage_time;
#if DEBUG
               HalUARTWrite(0,&a1, sizeof(a1));
#endif
             }

             else if((Water_gage_err >= Water_gage_err_a) && ( Water_gage_err < Water_gage_err_b))  
             {
               SendWaterGageTimeFreq += Water_gage_time;
#if DEBUG
               HalUARTWrite(0,&a2, sizeof(a2));
#endif
             }
            else if((Water_gage_err >= Water_gage_err_b) && ( Water_gage_err < Water_gage_err_c))
             {
               if(SendWaterGageTimeFreq >=Water_gage_time)
                 SendWaterGageTimeFreq -= Water_gage_time;
               else
                 SendWaterGageTimeFreq = 60;
#if DEBUG
               HalUARTWrite(0,&a3, sizeof(a3));
#endif
             }
             else if (Water_gage_err >= Water_gage_err_c)
             {
               SendWaterGageTimeFreq = (SendWaterGageTimeFreq/2) ;
#if DEBUG
               HalUARTWrite(0,&a4, sizeof(a4));
#endif
             }
           }
       // HalUARTWrite(0,(uint8*)&Water_gage_forValue, sizeof(Water_gage_forValue));
       // HalUARTWrite(0,(uint8*)&Water_gage_err, sizeof(Water_gage_err));      
       // HalUARTWrite(0,(uint8*)&SendWaterGageTimeFreq, sizeof(SendWaterGageTimeFreq));
       // HalUARTWrite(0,(uint8*)&UartHead, sizeof(UartHead))
       if ( SendWaterGageTimeFreq > 8*Water_gage_time )
             SendWaterGageTimeFreq = 8*Water_gage_time;
       else if( SendWaterGageTimeFreq < 60)
             SendWaterGageTimeFreq = 60;
        //HalUARTWrite(0,(uint8*)&SendWaterGageTimeFreq, sizeof(SendWaterGageTimeFreq));
#if DEBUG
       HalUARTWrite_uint16(SendWaterGageTimeFreq);
#endif
       
  //���յ����������ݺ�ʼԤ����һ������
       if(Water_gage_SerialNumber>=3)
         {
             Water_gage_forValue =Water_gage_forecastValue(Water_Gage_data_and_time);
              
             if (Water_gage_forValue > Water_gage_data_span)
               Water_gage_forValue = Water_gage_data_span;
             //HalUARTWrite(0,(uint8*)&Water_gage_forValue, sizeof(Water_gage_forValue));
#if DEBUG
             HalUARTWrite_uint16(Water_gage_forValue);
#endif
         } 

//P1_1����
       if(acceptance == 1)                    // ��Ŀ���ղŹر�ˮλ��
       {
         if(SendWaterGageTimeFreq >= 120)     //�ر�ˮλ���ŵ����� 2min
         {
            P1_1 = 0;                           //�ر�ˮλ��
         }
       }
       water_gage_on = 0;                     //�߼��ر�ˮλ��
       
       start_Water_gage_timer();
  }
    

  else
  {// Msg=0xAA 0x55 LEN AppHead(receive from ARM's Relation ACK Msg)
    uint8 temp_arm_id,temp_zigbee_id,temp_res;
    AppHead_t *AppHead = (AppHead_t *)(Msg+3);
      /*---------------------print-------------------*/
     // HalUARTWrite(0,Msg,10);
      /*********************************************/
      if(AppHead->type==TYPE_ACK)
      {
        if(AppHead->TypeCode==RELATION_MSG_DOWN)
        {
          temp_res=(Msg[7]&0xf0)>>4;
          temp_arm_id=(Msg[7]&0x0f);
          temp_zigbee_id=(Msg[8]&0xf0)>>4;
          if(Zigbee_ID==0 & ARM_ID==0)
          {
            ack_num=ack_num+1;
            ARM_ID=temp_arm_id;
            Zigbee_ID= temp_zigbee_id;
            RES=temp_res;
            Head_Map->addr16=0x0000;
            Head_Map->Zigbee_id=Zigbee_ID;
            FlagMap=ADDFLAG16(FlagMap,Zigbee_ID); 
          }
          else if(ARM_ID==temp_arm_id && Zigbee_ID== temp_zigbee_id )
          { 
            if(Zigbee_ID!=0)
            {
              if(relation_done == 0)
              {
                osal_stop_timerEx( p2p_test_TaskID,p2p_test_SEND_MAINTAIN_MSG_EVT);
                p2p_test_StartDataSensorTimer();
                relation_done =1;
              }
            }
          }
          else
          {
            afAddrType_t p2p_test_DstAddr_temp;
            p2p_test_DstAddr_temp.addrMode = (afAddrMode_t) AddrBroadcast;
            p2p_test_DstAddr_temp.endPoint = p2p_test_ENDPOINT;
            p2p_test_DstAddr_temp.addr.shortAddr = NWK_BROADCAST_SHORTADDR_DEVALL;
            AF_DataRequest( &p2p_test_DstAddr_temp, &p2p_test_epDesc,
                               p2p_test_RelationMsg,
                               Msg[2],
                               Msg+3,
                               &p2p_test_TransID,
                               AF_DISCV_ROUTE, AF_DEFAULT_RADIUS);
          
          }
        }
      }
      else if(AppHead->type==TYPE_COMMAND )
      {
        temp_arm_id=(Msg[7]&0x0f);
        temp_zigbee_id=(Msg[8]&0xf0)>>4;
        if(temp_arm_id==ARM_ID && temp_zigbee_id==Zigbee_ID)
          p2p_test_recv_108clusterId(Msg+3, Msg[2]);
        else
        {
            afAddrType_t p2p_test_DstAddr_temp;
            p2p_test_DstAddr_temp.addrMode = (afAddrMode_t) AddrBroadcast;
            p2p_test_DstAddr_temp.endPoint = p2p_test_ENDPOINT;
            p2p_test_DstAddr_temp.addr.shortAddr = NWK_BROADCAST_SHORTADDR_DEVALL;
            AF_DataRequest( &p2p_test_DstAddr_temp, &p2p_test_epDesc,
                               p2p_test_108ID,
                               Msg[2],
                               Msg+3,
                               &p2p_test_TransID,
                               AF_DISCV_ROUTE, AF_DEFAULT_RADIUS);
          
        }
          
      }

    
    
    //Msg = 0xAA 0x55 LEN shortaddr0 shortaddr1 DATA (Not include check, add short addr)
  //temporarily not consider broadcast
    /*
        uint16 shortAddr_temp = BUILD_UINT16(Msg[4], Msg[3]);
        AppHead_t *AppHead = (AppHead_t *)(Msg+5);
        uint8 SendOption;
        if(AppHead->AckRequire)
        {
              SendOption = AF_DISCV_ROUTE|AF_ACK_REQUEST;
        }
        else
        {
              SendOption = AF_DISCV_ROUTE;
        }
        
        if ( p2p_test_NwkState == DEV_ZB_COORD )
        {
          if(shortAddr_temp == 0x0000)
          {
            //maybe we will ack to arm if ack is required
            p2p_test_recv_108clusterId(Msg+5, Msg[2]-2);
          }
          else
          {
            afAddrType_t p2p_test_DstAddr_temp;
            p2p_test_DstAddr_temp.addrMode = (afAddrMode_t)Addr16Bit;
            p2p_test_DstAddr_temp.endPoint = p2p_test_ENDPOINT;
            p2p_test_DstAddr_temp.addr.shortAddr = shortAddr_temp;
          
            AF_DataRequest( &p2p_test_DstAddr_temp, &p2p_test_epDesc,
                               p2p_test_108ID,
                               Msg[2]-2,
                               Msg+5,
                               &p2p_test_TransID,
                               SendOption, AF_DEFAULT_RADIUS);//need ack
      
          }
        }
    */
    
   }
}

/*********************************************************************
 * @fn      p2p_test_SendToUart
 *
 * @brief   
 *
 * @param   none
 *
 * @return  none
 */
void p2p_test_SendToUart(uint8 *Data, uint8 DataLength)
{  
  UartHeadMsg_t UartHead;
  uint8 check[2],checksum;
  
  UartHead.head[0] = 0xAA;
  UartHead.head[1] = 0x55;
  UartHead.len = DataLength;
  check[0] = SPIMgr_CalcFCS((uint8*)&UartHead,3);  
  check[1] = SPIMgr_CalcFCS(Data,DataLength);
  checksum = SPIMgr_CalcFCS(check,2);
  
  HalUARTWrite(0,(uint8*)&UartHead, sizeof(UartHead));
  HalUARTWrite(0, Data, DataLength);
  HalUARTWrite(0, (uint8*)&checksum, 1);
}

/*********************************************************************
 * @fn      fill_AppHead
 *
 * @brief   
 *
 * @param   none
 *
 * @return  none
 */
void fill_AppHead(AppHead_t *AppHead, uint8 AckRequire, uint8 MainVersion, uint8 SubVersion, uint8 type, uint8 TypeCode)
{
  AppHead->AckRequire = AckRequire;
  AppHead->MainVersion = MainVersion;
  AppHead->SubVersion = SubVersion;
  AppHead->type = type;
  AppHead->TypeCode = TypeCode;
  //SerialNumber++;
  uint16 SerialNumber = 0;
  
  AppHead->sn[0] = HI_UINT16(SerialNumber);
  AppHead->sn[1] = LO_UINT16(SerialNumber);  
}
//�����кŵ�ack��ͷ��
void fill_AppHead_sn(AppHead_t *AppHead, uint8 AckRequire, uint8 MainVersion, uint8 SubVersion, uint8 type, uint8 TypeCode,uint16 SerialNumber)
{
  AppHead->AckRequire = AckRequire;
  AppHead->MainVersion = MainVersion;
  AppHead->SubVersion = SubVersion;
  AppHead->type = type;
  AppHead->TypeCode = TypeCode;
  AppHead->sn[0] = HI_UINT16(SerialNumber);
  AppHead->sn[1] = LO_UINT16(SerialNumber);  
}
/*********************************************************************
 * @fn      fill_NodeId_time
 *
 * @brief   
 *
 * @param   none
 *
 * @return  none
 */
void fill_NodeId_time(NodeIdAndTime_t *NodeIdAndTime,uint8 ARM_Id,uint8 Zigbee_Id,uint8 sensor_type)
{
  /*uint32*/ now = osal_GetSystemClock();  
  NodeIdAndTime->time[0] = BREAK_UINT32(now, 3);
  NodeIdAndTime->time[1] = BREAK_UINT32(now, 2);
  NodeIdAndTime->time[2] = BREAK_UINT32(now, 1);
  NodeIdAndTime->time[3] = BREAK_UINT32(now, 0); 
  NodeIdAndTime->NodeId.r=RES;
  NodeIdAndTime->NodeId.ARM_id=ARM_Id;
  NodeIdAndTime->NodeId.Zigbee_id = Zigbee_Id;
  NodeIdAndTime->NodeId.sensor_type=sensor_type;
}

/*********************************************************************
 * @fn      SendMsg
 *
 * @brief   
 *
 * @param   none
 *
 * @return  none
 */
void SendMsg(uint8 *msg, uint8 MsgSize, afAddrType_t Dst, uint8 options,uint16 cID)
{
  if ( p2p_test_NwkState == DEV_ZB_COORD )
  {
    p2p_test_SendToUart(msg, MsgSize);
  }
  else
  {
    AF_DataRequest( &Dst, &p2p_test_epDesc,
                       cID,
                       MsgSize,
                       msg,
                       &p2p_test_TransID,
                       options, AF_DEFAULT_RADIUS );
#if DEBUG
          p2p_test_SendToUart(msg, MsgSize);//���Ӳ��� ��ͨ������
#endif
  }  
}

/*********************************************************************
 * @fn      p2p_test_SendResetRelativeTime
 *
 * @brief   
 *
 * @param   none
 *
 * @return  none
 */
void p2p_test_SendResetRelativeTime( void )
{
  /*
  ResetTimeMsg_t ResetTimeMsg;
  
  fill_AppHead((AppHead_t *)&ResetTimeMsg.AppHead, ACK_YES, MAIN_VERSION, SUB_VERSION, TYPE_MAINTAIN, TYPE_CODE_MAINTAIN_RESET_TIME);
  fill_NodeId_time((NodeIdAndTime_t *)&temp_water_gage.NodeIdAndTime,ARM_ID,Zigbee_ID,0);//start from load 
  
  SendMsg((uint8 *)&ResetTimeMsg, sizeof(ResetTimeMsg), p2p_test_DstAddr, AF_DISCV_ROUTE|AF_ACK_REQUEST,p2p_test_RealtionMsg);//need ack 
  */
}

/*********************************************************************
 * @fn      p2p_test_SendRelationPkt
 *
 * @brief   
 *
 * @param   none
 *
 * @return  none
 */
void p2p_test_SendRelationPkt()
{
  osal_start_timerEx( p2p_test_TaskID,
                     p2p_test_SEND_MAINTAIN_MSG_EVT,5000); 
  RelationMsg_t RelationMsg;
  uint16 num;
  num=0;
  //zigbee's own id
  RelationMsg.NodeId[0].r=0x00;
  RelationMsg.NodeId[0].ARM_id=ARM_ID;
  RelationMsg.NodeId[0].Zigbee_id=Zigbee_ID;
  RelationMsg.NodeId[0].sensor_type=0;
  #if RAIN_FLAG!=0
     num++;
     RelationMsg.NodeId[num].sensor_type=RAIN_ID;
  #endif
  #if SOIL_FLAG!=0
     num++;
     RelationMsg.NodeId[num].sensor_type=SOIL_ID;
  #endif
  #if WATER_GAGE_FLAG!=0
     num++;
     RelationMsg.NodeId[num].sensor_type=WATER_GAGE_ID;
  #endif
  #if EARTHQUAKE_FLAG!=0
     num++;
     RelationMsg.NodeId[num].sensor_type=EARTHQUAKE_ID;
  #endif
  #if PORE_FLAG!=0
     num++;
     RelationMsg.NodeId[num].sensor_type=PORE_ID;
  #endif
  
  uint8 i;
  for(i=1;i<=num;i++)
  {
    RelationMsg.NodeId[i].r=0;
    RelationMsg.NodeId[i].ARM_id=ARM_ID;
    RelationMsg.NodeId[i].Zigbee_id=Zigbee_ID;
  }
  fill_AppHead((AppHead_t *)&RelationMsg.AppHead, ACK_YES, MAIN_VERSION, SUB_VERSION, TYPE_MAINTAIN,RELATION_MSG_UP);
  if(0==Zigbee_ID)//first send RelationMsg
  {
    
    RelationMsg.Num[0]=0x00;
    RelationMsg.Num[1]=0x00;
   // SendMsg((uint8 *)&RelationMsg, sizeof(RelationMsg)-2*(MAX_ID-0), p2p_test_DstAddr, AF_DISCV_ROUTE,p2p_test_RelationMsg);//need ack
    //EndDevice print
   // HalUARTWrite(0,&Zigbee_ID,1);
    SendMsg((uint8 *)&RelationMsg, sizeof(RelationMsg), p2p_test_DstAddr, AF_DISCV_ROUTE,p2p_test_RelationMsg);
  }
  else      //second send RElationMsg
  {
    RelationMsg.Num[0]=HI_UINT16(num+1);
    RelationMsg.Num[1]=LO_UINT16(num+1);
  //  SendMsg((uint8 *)&RelationMsg, sizeof(RelationMsg)-2*(MAX_ID-num-1), p2p_test_DstAddr, AF_DISCV_ROUTE,p2p_test_RelationMsg);//need ack
    SendMsg((uint8 *)&RelationMsg, sizeof(RelationMsg), p2p_test_DstAddr, AF_DISCV_ROUTE,p2p_test_RelationMsg);
    //EndDevice print
   //HalUARTWrite(0,&Zigbee_ID,1);
  }

  
 // shortaddr = NLME_GetShortAddr();
  //RelationMsg.ShortAddr[0] = HI_UINT16(shortaddr);
 // RelationMsg.ShortAddr[1] = LO_UINT16(shortaddr);
    
}

void p2p_test_StartDataSensorTimer()
{
#if RAIN_FLAG!=0
        osal_start_timerEx( p2p_test_TaskID,
                              p2p_test_SEND_RAIN_FREQ_MSG_EVT,
                              1000 );     
#endif
#if SOIL_FLAG!=0
        osal_start_timerEx(p2p_test_TaskID,
                              p2p_test_SEND_SOIL_HUMIDITY_FREQ_MSG_EVT,
                              2000); 
#endif    
#if EARTHQUAKE_FLAG!=0 
      
        osal_start_timerEx(p2p_test_TaskID,
                              p2p_test_SEND_ACCELEROMETER_FREQ_MSG_EVT,
                               1000);
#endif         
         
           
            //  uint8 te=0xAA;
            //  HalUARTWrite(0,&te,1);

           
           
  /*         osal_start_timerEx(p2p_test_TaskID,
                              p2p_test_SEND_VCC_VALUE_FREQ_MSG_EVT ,
                              1000);   
  */        

     /*   if (  (p2p_test_NwkState == DEV_ROUTER)
              || (p2p_test_NwkState == DEV_END_DEVICE) )
          {
              osal_start_timerEx( p2p_test_TaskID,
                                p2p_test_SEND_MSG_EVT,
                               10 );
          }  */
#if WATER_GAGE_FLAG!=0   
    osal_start_timerEx(p2p_test_TaskID,
                             p2p_test_SEND_WATER_GAGE_MSG_EVT,
                             1000); 
    osal_start_timerEx(p2p_test_TaskID,
                          p2p_test_CHECK_WATER_GAGE_CHARGE_MSG_EVT, 
                          CheckWaterGageChargeTimeFreq * 1000);
   /*  osal_start_timerEx( p2p_test_TaskID,
                          p2p_test_START_WATER_GAGE_TIME_MSG_EVT, 
                          1000);*/
 #endif 
}

/*********************************************************************
 * @fn      p2p_test_interrupt_rain
 *
 * @brief   
 *
 * @param   none
 *
 * @return  none
 */
void p2p_test_interrupt_rain(uint16 count)
{
  if(++RainCountNum != SendRainCountFreq)
  {
    return;
  }
  if(count>=RainCountNum)
    count=count-RainCountNum;
    //reset

  RainMsg_t RainMsg;  
  fill_AppHead((AppHead_t *)&RainMsg.AppHead, ACK_NO, MAIN_VERSION, SUB_VERSION, TYPE_SENSOR, TYPE_CODE_SENSOR_RAIN);
  fill_NodeId_time((NodeIdAndTime_t *)&RainMsg.NodeIdAndTime,ARM_ID,Zigbee_ID,RAIN_ID);//start from load  
  RainMsg.count[0] = HI_UINT16(RainCountNum);
  RainMsg.count[1] = LO_UINT16(RainCountNum);
  RainCountNum=0;
  SendMsg((uint8 *)&RainMsg, sizeof(RainMsg), p2p_test_DstAddr, AF_DISCV_ROUTE,p2p_test_108ID);//no ack
}

/*********************************************************************
 * @fn      p2p_test_SendRainTimeFreqAndRequire
 *
 * @brief   
 *
 * @param   none
 *
 * @return  none
 */
void p2p_test_SendRainTimeFreqAndRequire( uint8 FreqOrRequire )
{
  if(FreqOrRequire == FREQ)
  {
    uint8 timeout = 0;  
    if(!SendRainRemainTime)//SendRainRemainTime==0, send the msg
    {
      SendRainRemainTime = SendRainTimeFreq;//test unit=second, product unit=minute
      //SendRainRemainTime = SendRainTimeFreq*60;
      timeout = 1;
    }

    if(SendRainRemainTime>65)//osal_start_timerEx max time is 65.535s
    {
      SendRainRemainTime -= 65;
      osal_start_timerEx( p2p_test_TaskID,
                      p2p_test_SEND_RAIN_FREQ_MSG_EVT,
                      65000 );//uint=ms
    }
    else
    {
       osal_start_timerEx( p2p_test_TaskID,
                      p2p_test_SEND_RAIN_FREQ_MSG_EVT,
                      SendRainTimeFreq*1000 );
       SendRainRemainTime = 0;
    }
    if(!timeout)
    {
      return;      
    }
  }
  
  static uint16 precount=0;
  RainMsg_t RainMsg;
  uint8 SendMsgOption, AckRequire;
  if(FreqOrRequire == FREQ)
  {
    SendMsgOption = AF_DISCV_ROUTE;
    AckRequire = ACK_NO;
  }
  else
  {
    SendMsgOption = AF_DISCV_ROUTE|AF_ACK_REQUEST;
    AckRequire = ACK_YES;      
  }
  fill_AppHead((AppHead_t *)&RainMsg.AppHead, AckRequire, MAIN_VERSION, SUB_VERSION, TYPE_SENSOR, TYPE_CODE_SENSOR_RAIN);
  fill_NodeId_time((NodeIdAndTime_t *)&RainMsg.NodeIdAndTime,ARM_ID,Zigbee_ID,RAIN_ID);;//start from load  
  uint16 count = QueryP1Interrupt(PIN_3);
  RainMsg.count[0] = HI_UINT16(count-precount);
  RainMsg.count[1] = LO_UINT16(count-precount);
  precount=count;
  SendMsg((uint8 *)&RainMsg, sizeof(RainMsg), p2p_test_DstAddr, SendMsgOption,p2p_test_108ID);
}

/*********************************************************************
 * @fn      p2p_test_SendSoilHumidityTimeFreqAndRequire
 *
 * @brief   
 *
 * @param   none
 *
 * @return  none
 */
void p2p_test_SendSoilHumidityTimeFreqAndRequire( uint8 FreqOrRequire )
{
  /*if(FreqOrRequire == FREQ)
  {
    uint8 timeout = 0;  
    if(!SendSoilHumidityRemainTime)//SendIlluminationRemainTime==0, send the msg
    {
      SendSoilHumidityRemainTime = SendSoilHumidityTimeFreq;//test unit=second product unit=minute
      //SendIlluminationRemainTime = SendIlluminationTimeFreq*60;
      timeout = 1;
    }

    if(SendSoilHumidityRemainTime>65)//osal_start_timerEx max time is 65.535s
    {
      SendSoilHumidityRemainTime -= 65;
      osal_start_timerEx( p2p_test_TaskID,
                      p2p_test_SEND_SOIL_HUMIDITY_FREQ_MSG_EVT,
                      65000 );//uint=ms
    }
    else
    {
       osal_start_timerEx( p2p_test_TaskID,
                      p2p_test_SEND_SOIL_HUMIDITY_FREQ_MSG_EVT,
                      SendSoilHumidityTimeFreq*1000 );
       SendSoilHumidityRemainTime = 0;
    }
    if(!timeout)
    {
      return;      
    }
  }
  */
  
  uint16 AdcValue=0,AdcVcc=0;
 // float tmp_value;
  //P0.1 IS GENERAL AND INPUT
  P0SEL &=~ (0x02);
  P0DIR &=~ (0x02);
  HalAdcInit();
  //adcground=HalAdcCheckGround(HAL_ADC_RESOLUTION_14);
  AdcVcc = HalAdcReadVcc( HAL_ADC_RESOLUTION_14 );
  AdcValue = HalAdcRead(1,HAL_ADC_RESOLUTION_14);
  AdcVcc = AdcVcc*3;
  
  Soil_Humidity_t Soil_Humidity;
  uint8 SendMsgOption, AckRequire;
  
  if(FreqOrRequire == FREQ)
  {
    SendMsgOption = AF_DISCV_ROUTE|AF_ACK_REQUEST;
    AckRequire = ACK_NO;    
  }
  else{
    SendMsgOption = AF_DISCV_ROUTE|AF_ACK_REQUEST;
    AckRequire = ACK_YES;     
  }
  fill_AppHead((AppHead_t *)&Soil_Humidity.AppHead, AckRequire, MAIN_VERSION, SUB_VERSION, TYPE_SENSOR, TYPE_CODE_SENSOR_SOIL_HUMIDITY);
  fill_NodeId_time((NodeIdAndTime_t *)&Soil_Humidity.NodeIdAndTime,ARM_ID,Zigbee_ID,SOIL_ID);  
  Soil_Humidity.AdcVcc[0] = HI_UINT16(AdcVcc);
  Soil_Humidity.AdcVcc[1] = LO_UINT16(AdcVcc);
  Soil_Humidity.AdcValue[0] = HI_UINT16(AdcValue);
  Soil_Humidity.AdcValue[1] = LO_UINT16(AdcValue);
  //GET PORT OF VALUE P0.1
 /* tmp_value = (float)AdcValue/0x1FFF;
  tmp_value = (float)AdcVcc/0x1FFF*1.25*tmp_value;
  if(tmp_value <= 2.5)
  {
    switch(SOIL_TYPE)
    {
     case Clay_Soil:
          Soil_Humidity.SoilValue = (0.055*tmp_value*tmp_value+0.02*tmp_value-0.0002)*100;
     break;
     case Loam_Soil:
          Soil_Humidity.SoilValue = (0.0145*tmp_value*tmp_value+0.1022*tmp_value+0.0003)*100;
     break;
     case Sand_Soil:
     Soil_Humidity.SoilValue = (0.0154*tmp_value*tmp_value+0.1438*tmp_value-0.0026)*100;
     break;
    }
  } 
  else 
  { 
    Soil_Humidity.SoilValue= 100.0;
  } */
  SendMsg((uint8 *)&Soil_Humidity, sizeof(Soil_Humidity), p2p_test_DstAddr, SendMsgOption,p2p_test_108ID);  

//�Լ���д
  

  uint16 Soil_humidity_data_temp = BUILD_UINT16(Soil_Humidity.AdcValue[1], 
                                                Soil_Humidity.AdcValue[0]);
  uint16 Soil_humidity_vcc_temp = BUILD_UINT16(Soil_Humidity.AdcVcc[1], 
                                               Soil_Humidity.AdcVcc[0]);
  float Soil_humidity_data =Soil_humidity_DtoA(Soil_humidity_data_temp,Soil_humidity_vcc_temp);
  //HalUARTWrite(0,(uint8 *)&(temp_water_gage.water_gage_value),sizeof(temp_water_gage.water_gage_value));
  //uint16 data = BUILD_UINT16(Msg[3], Msg[4]);
  //HalUARTWrite(0,(uint8*)&data, sizeof(data));
  //���ڲ���
     uint8 a1 =1;
     uint8 a2 =2;
     uint8 a3 =3;
     uint8 a4 =4;
     
      float x=Soil_humidity_data*100;
      HalUARTWrite_uint16((uint16)x);

       Soil_humidity_data_and_time.data[Soil_humidity_SerialNumber%3]=Soil_humidity_data;
       Soil_humidity_data_and_time.time[Soil_humidity_SerialNumber%3]= now;
              
      // HalUARTWrite(0,(uint8*)&Water_Gage_data_and_time.time[0], sizeof(Water_Gage_data_and_time.time[0]));
      // HalUARTWrite(0,(uint8*)&Water_Gage_data_and_time.time[1], sizeof(Water_Gage_data_and_time.time[1]));
      // HalUARTWrite(0,(uint8*)&Water_Gage_data_and_time.time[2], sizeof(Water_Gage_data_and_time.time[2]));
       
     //  HalUARTWrite(0,(uint8*)& Water_Gage_data_and_time.data[Water_gage_SerialNumber%3], sizeof( Water_Gage_data_and_time.data[Water_gage_SerialNumber%3]));
       Soil_humidity_SerialNumber++;
  
  //����Ԥ��ֵѡ��ʱ��ʱ��
       if(Soil_humidity_SerialNumber >=4)
           {
            Soil_humidity_err = (Soil_humidity_data >Soil_humidity_forValue )? 
                ( Soil_humidity_data- Soil_humidity_forValue) : 
                 (Soil_humidity_forValue -Soil_humidity_data);    
        
            float y =Soil_humidity_err*100;
            HalUARTWrite_uint16((uint16)y);
           // HalUARTWrite_uint16((uint16)&x);
  
            
             if( Soil_humidity_err < Soil_humidity_err_a)
             {
               SendSoilHumidityTimeFreq += 2*Soil_humidity_time;
               HalUARTWrite(0,&a1, sizeof(a1));
             }

             else if((Soil_humidity_err >= Soil_humidity_err_a) && ( Soil_humidity_err < Soil_humidity_err_b))  
             {
               SendSoilHumidityTimeFreq += Soil_humidity_time;
               HalUARTWrite(0,&a2, sizeof(a2));
             }
            else if((Soil_humidity_err >= Soil_humidity_err_b) && ( Soil_humidity_err < Soil_humidity_err_c))
             {
               SendSoilHumidityTimeFreq -= Soil_humidity_time;
               HalUARTWrite(0,&a3, sizeof(a3));
             }
             else if (Soil_humidity_err >= Soil_humidity_err_c)
             {
               SendSoilHumidityTimeFreq = (SendSoilHumidityTimeFreq/2) ;
               HalUARTWrite(0,&a4, sizeof(a4));
             }
           }
       // HalUARTWrite(0,(uint8*)&Water_gage_forValue, sizeof(Water_gage_forValue));
       // HalUARTWrite(0,(uint8*)&Water_gage_err, sizeof(Water_gage_err));      
       // HalUARTWrite(0,(uint8*)&SendWaterGageTimeFreq, sizeof(SendWaterGageTimeFreq));
       // HalUARTWrite(0,(uint8*)&UartHead, sizeof(UartHead))
       if ( SendSoilHumidityTimeFreq > 8*Soil_humidity_time)
             SendSoilHumidityTimeFreq = 8*Soil_humidity_time;
       
        //HalUARTWrite(0,(uint8*)&SendWaterGageTimeFreq, sizeof(SendWaterGageTimeFreq));
        HalUARTWrite_uint16(SendSoilHumidityTimeFreq);
        
  //���յ����������ݺ�ʼԤ����һ������
       if(Soil_humidity_SerialNumber>=3)
         {
             Soil_humidity_forValue =Soil_humidity_forecastValue(Soil_humidity_data_and_time);
              if(Soil_humidity_forValue < 0 ) 
                Soil_humidity_forValue=0;
              else if(Soil_humidity_forValue > 2.5)
                Soil_humidity_forValue = 2.5;
             //HalUARTWrite(0,(uint8*)&Water_gage_forValue, sizeof(Water_gage_forValue));
            float z =Soil_humidity_forValue*100;
           HalUARTWrite_uint16((uint16)z);
         } 

       
        start_Soil_humidity_timer();
      // conPrintROMString("shoudao yige shuju ");



}


/*********************************************************************
 * @fn      p2p_test_SendAccelerometerTimeFreqAndRequire
 *
 * @brief   
 *
 * @param   none
 *
 * @return  none
 */
void p2p_test_SendAccelerometerTimeFreqAndRequire( uint8 FreqOrRequire )
{
  if(FreqOrRequire == FREQ)
  {
    uint8 timeout = 0;  
    if(!SendAccelerometerRemainTime)//SendIlluminationRemainTime==0, send the msg
    {
      SendAccelerometerRemainTime = SendAccelerometerTimeFreq;//test unit=second product unit=minute
      //SendIlluminationRemainTime = SendIlluminationTimeFreq*60;
      timeout = 1;
    }

    if(SendAccelerometerRemainTime>65)//osal_start_timerEx max time is 65.535s
    {
      SendAccelerometerRemainTime -= 65;
      osal_start_timerEx( p2p_test_TaskID,
                      p2p_test_SEND_ACCELEROMETER_FREQ_MSG_EVT,
                      65000 );//uint=ms
    }
    else
    {
       osal_start_timerEx( p2p_test_TaskID,
                       p2p_test_SEND_ACCELEROMETER_FREQ_MSG_EVT,
                       SendAccelerometerTimeFreq*1000 );
       SendAccelerometerRemainTime = 0;
    }
    if(!timeout)
    {
      return;      
    }
  }
  
  uint16 AdcValue=0,AdcVcc=0;
  //HalUARTWrite(0,(uint8 *))
 // float tmp_value;
  //P0.7 is input externel Vcc
  //p0.4 p0.5 is about differential input
  // P0SEL &=~ (0x04);
   //P0DIR &=~ (0x04);
 //  P0SEL &=~ (0x30);
 //  P0DIR &=~ (0x30);
   P0SEL &=~ (0xc0);
   P0DIR &=~ (0xc0);
  HalAdcInit();
  //adcground=HalAdcCheckGround(HAL_ADC_RESOLUTION_14);
  //float tempvalue;
  AdcVcc = HalAdcReadVcc( HAL_ADC_RESOLUTION_14 );
 // AdcValue = HalAdcRead(5,HAL_ADC_RESOLUTION_14); 
  AdcValue=  HalDiffAdcRead(6,7,HAL_ADC_RESOLUTION_14);
  //tempvalue=(float)AdcVcc/0x1fff;
  //tempvalue=(float)AdcValue/0x1fff*tempvalue*5;
  
  Accelerometer_t Accelerometer;
  uint8 SendMsgOption, AckRequire;
  
  if(FreqOrRequire == FREQ)
  {
    SendMsgOption = AF_DISCV_ROUTE|AF_ACK_REQUEST;
    AckRequire = ACK_NO;    
  }
  else{
    SendMsgOption = AF_DISCV_ROUTE|AF_ACK_REQUEST;
    AckRequire = ACK_YES;     
  }
  fill_AppHead((AppHead_t *)&Accelerometer.AppHead, AckRequire, MAIN_VERSION, SUB_VERSION, TYPE_SENSOR, TYPE_CODE_SENSOR_ACCELEROMETER);
  fill_NodeId_time((NodeIdAndTime_t *)&Accelerometer.NodeIdAndTime,ARM_ID,Zigbee_ID,EARTHQUAKE_ID);  
  Accelerometer.AdcVcc[0] = HI_UINT16(AdcVcc);
  Accelerometer.AdcVcc[1] = LO_UINT16(AdcVcc);
  Accelerometer.AdcValue[0] = HI_UINT16(AdcValue);
  Accelerometer.AdcValue[1] = LO_UINT16(AdcValue);
 // Accelerometer.Accelevalue=tempvalue;
  SendMsg((uint8 *)&Accelerometer, sizeof(Accelerometer), p2p_test_DstAddr, SendMsgOption,p2p_test_108ID);  
}
/*********************************************************************
 * @fn      p2p_test_Send_VCC_VALUE
 *
 * @brief   read vcc and sent to coor.COMMOND FOR supply voltage. read digital value is vcc/3 and ref 
 *          value is 1.25v of internal voltage .  RESOLUTION is 14 bit .if the dev is coor, 
 *          send to pc through serial port,other send to coor.
 *
 * @param   Freq: the time , send data to coor unit s
 *          Require: the commend for read value once
 *
 * @return  none
 */
void p2p_test_Send_VCC_VALUE(uint8 FreqOrRequire)
{
   if (FreqOrRequire == FREQ)
   {
     uint8 timeout = 0;
     if(!SendVccValueRemainTime)
     {
       SendVccValueRemainTime = SendVccValueTimeFreq;
       timeout = 1;
     }
     if(SendVccValueRemainTime > 65)//osal_start_timerEx max time is 65.535s
     {
       SendVccValueRemainTime -= 65;
       osal_start_timerEx( p2p_test_TaskID,
                          p2p_test_SEND_VCC_VALUE_FREQ_MSG_EVT, 
                          65000);
     }
     else 
     {
       osal_start_timerEx(p2p_test_TaskID,
                          p2p_test_SEND_VCC_VALUE_FREQ_MSG_EVT, 
                          SendVccValueTimeFreq*1000);
      SendVccValueRemainTime = 0;
     }
     if(!timeout)
     {
       return;
     }
   }
  //set read adc
    uint16 AdcVccTmp =0;
    Vccvalue_t Vccvalue;
    uint8 SendMsgOption, AckRequire;
    HalAdcInit();
    AdcVccTmp = HalAdcReadVcc(HAL_ADC_RESOLUTION_14);
    AdcVccTmp = AdcVccTmp*3;
    
    if(FreqOrRequire == FREQ)
    {
      SendMsgOption = AF_DISCV_ROUTE;
      AckRequire = ACK_NO;
    }   
    else
     {
      SendMsgOption = AF_DISCV_ROUTE|AF_ACK_REQUEST;
      AckRequire = ACK_YES;          
     }
    fill_AppHead((AppHead_t *)&Vccvalue.AppHead,AckRequire,MAIN_VERSION,
                 SUB_VERSION,TYPE_SENSOR,TYPE_CODE_SENSOR_READ_VCC);
    fill_NodeId_time((NodeIdAndTime_t *)&Vccvalue.NodeIdAndTime,ARM_ID,Zigbee_ID,0);
    Vccvalue.AdcVcc[0] =  HI_UINT16(AdcVccTmp);
    Vccvalue.AdcVcc[1] =  LO_UINT16(AdcVccTmp);
    SendMsg((uint8 *)&Vccvalue, sizeof(Vccvalue), p2p_test_DstAddr, 
            SendMsgOption,p2p_test_108ID); 
 }


//*********************************************************************
 /* @fn       crc_water_gage
 *
 * @brief   
 *
 * @param   Freq: the time , send data to coor unit s
 *          Require: the commend for read value once
 *
 * @return  none
 */
void crc_water_gage(Water_Send_Infor_t *temp)
{
   uint16 Crc=0xffff;
   uint16 a001=0xa001;
   
   uint8 a[6],crc[2];
   a[0]=temp->station_number;
   a[1]=temp->func_code;
   a[2]=temp->first_addr[0];
   a[3]=temp->first_addr[1];
   a[4]=temp->read_num[0];
   a[5]=temp->read_num[1];

   for(int i=0;i<6;i++)
   {   
       crc[0]= LO_UINT16(Crc);
       crc[1]= HI_UINT16(Crc);
       crc[0]=crc[0]^a[i];
       Crc= BUILD_UINT16(crc[0],crc[1]);
      	for(int j=0;j<8;j++)
	{
	   if((Crc&0x0001)==1)
	   {
	     Crc=(Crc>>1)&0x7fff;
             Crc=Crc^a001;
	   }
	   else if((Crc&0x0001)==0)
	    Crc=(Crc>>1)&0x7fff;
	}
		
   }
  // uint8 a,b;
    temp->crc[0]=LO_UINT16(Crc);
    temp->crc[1]=HI_UINT16(Crc);
   
}

/*********************************************************************
 * @fn      p2p_test_Send_Water_Gage
 *
 * @brief   
 *
 * @param   Freq: the time , send data to coor unit s
 *          Require: the commend for read value once
 *
 * @return  none
 */
void p2p_test_Send_Water_Gage(uint8 FreqOrRequire,uint16 watergageuint)
{
 // if (FreqOrRequire == FREQ)
  //  start_Water_gage_timer();
 /*  {
     uint8 timeout = 0;
     if(!SendWaterGageRemainTime)
     {
       SendWaterGageRemainTime= SendWaterGageTimeFreq;
       timeout = 1;
     }
     if(SendWaterGageRemainTime > 65)//osal_start_timerEx max time is 65.535s
     {
       SendWaterGageRemainTime-= 65;
       osal_start_timerEx( p2p_test_TaskID,
                          p2p_test_SEND_WATER_GAGE_MSG_EVT, 
                          65000);
     }
     else 
     {
       osal_start_timerEx(p2p_test_TaskID,
                          p2p_test_SEND_WATER_GAGE_MSG_EVT, 
                          SendWaterGageRemainTime*1000);
      SendWaterGageRemainTime= 0;
     }
     if(!timeout)
     {
       return;
     }
   }*/
//P1_1����
  if(water_gage_on ==0 )
  {
    if(acceptance == 1)
    {
       P1_1 = 1;//����ˮλ��
    }
    else if(acceptance == 0 && P1_1 == 0 )
    {
      P1_1 = 1;
    }
    P1_1 = 1;
    water_gage_on = 1;
    osal_start_timerEx(p2p_test_TaskID,
                   p2p_test_SEND_WATER_GAGE_MSG_EVT, 
                   60000);   //�ȴ�һ���ӣ���ʹˮλ�������ȶ�
  } 
  else 
  {
     no_charge_flag =1;
 //send to uart 
     Water_Send_Infor_t *temp_water=(Water_Send_Infor_t *)osal_msg_allocate(sizeof(Water_Send_Infor_t));
     temp_water->station_number=Station_Num;
     temp_water->func_code=Water_Func_Code;
     temp_water->first_addr[0]=HI_UINT16(watergageuint);
     temp_water->first_addr[1]=LO_UINT16(watergageuint);
     temp_water->read_num[0]=HI_UINT16(Water_num);
     temp_water->read_num[1]=LO_UINT16(Water_num);
     crc_water_gage(temp_water);
     P1_0=1;
    // P2_0=1;
     halWait(21);
   //  halWait(251);
   //  halWait(251);
  // HalUARTWrite(0, (uint8 *)(temp_water),sizeof(Water_Send_Infor_t)); 
   HalUARTWrite(1, (uint8 *)temp_water,sizeof(Water_Send_Infor_t)); 
   halWait(15);
   osal_msg_deallocate((uint8 *)temp_water);
   P1_0=~P1_0;
    
   //  halWait(20);
   
    // Water_Gage_t  temp_water_gage;
 
   
    /* temp_water.station_number=0x01;
     temp_water.func_code=0x03;
     temp_water.first_addr[0]=0x00;
     temp_water.first_addr[1]=0x01;
     temp_water.read_num[0]=0x00;
     temp_water.read_num[1]=0x02;
    // uint8 a=0x01;
     crc_water_gage(&temp_water);*/
     
    // temp_water.crc[0]=0xc4;//LO_UINT16(crc_water_gage(&temp));
     //temp_water.crc[1]=0x0b;//HI_UINT16(crc_water_gage(&temp));
      //p2p_test_SendToUart((uint8 *)(&a),1);
  }   
 }



/*********************************************************************
 * @fn      halWait
 *
 * @brief   
 *
 * @param   none
 *
 * @return  none
 */
uint8 halWait(unsigned char wait){
   unsigned long largeWait;

   if(wait == 0)
   {return 0;}
   largeWait = ((unsigned short) (wait << 7));
   largeWait += 114*wait;


   largeWait = (largeWait >> CLKSPD);
   while(largeWait--);

   return 0;
}

//test for route to route

/*
void READ_TEST(afIncomingMSGPacket_t *pkt )
{
   // afIncomingMSGPacket_t *tmp_pkt=(afIncomingMSGPacket_t)*pkt;
   // p2p_test_SendToUart(pkt->cmd.Data, pkt->cmd.DataLength);
    HalUARTWrite(0,(pkt->cmd.Data), pkt->cmd.DataLength);
}
*/

void insert_RelationMap(struct RelationMap_t *map,uint16 addr,uint8 zigbee_id)
{
   struct RelationMap_t *temp_map=Tail_Map;
   map=(struct RelationMap_t *)osal_msg_allocate(sizeof(struct RelationMap_t));
   map->addr16=addr;
   map->Zigbee_id=zigbee_id;
   if(temp_map!=NULL && map!=NULL)
   {
     Tail_Map->next=map;
     Tail_Map=map;
   }
   //osal_msg_deallocate((uint8 *)map);
}


uint8 search_RelationMap(uint16 addr)
{
  struct RelationMap_t *temp_map;
  temp_map=Head_Map;
  while(temp_map!=NULL)
  {
    if(addr==temp_map->addr16)
    {
      return (temp_map->Zigbee_id);
    }
    else
    {
      temp_map=temp_map->next;
    }
  }
  return 0;
}